--SMB1: Chaos Edition

-- Normal Chaos:
-- Chaos  1 (Music Tempo Changing)
-- Chaos  2 (Enemies WOOSH)
-- Chaos  3 (Enemies WEEEE)
-- Chaos  4 (Mario Velocity Change)
-- Chaos  5 (Swim Toggle)
-- Chaos  6 (Level Change #1)
-- Chaos  7 (Level Change #2)
-- Chaos  8 (Gravity Change)
-- Chaos  9 (Mario Teleportation)
-- Chaos 10 (Enemy Portals)
-- Chaos 11 (Lakitu/Bowser Super Saiyan Mode)
-- Chaos 12 (Mario Portals)
-- Chaos 13 (Timer Changes)
-- Chaos 14 (Frozen Velocity)
-- Chaos 15 (Sprite Fuckery)
-- Chaos 16 (Instant Acceleration + Jitters)
-- Chaos 17 (Enemies match Mario Velocity)
-- Chaos 18 (Mario's sprite alters)
-- Chaos 19 (Level Palette Change)
-- Chaos 20 (Level "Location" Change)
-- Chaos 21 (Character Change)
-- Chaos 22 (Music Change)
-- Chaos 23 (Mario Bouncy!)
-- Chaos 24 (Terrain Fuckery)
-- Chaos 25 (Background Change)
-- Chaos 26 (Bud's Nightmare)
-- Chaos 27 (Kaizo, bitch || random Invisible coin blocks) (fuck you chibi)
-- Chaos 28 (Lakitu Party!!!)
-- Chaos 29 (Oops, my platorms broke)
-- Chaos 30 (Block Scrambler)
-- Chaos 31 (Scroll Stop for a few moments!)
-- Chaos 32 (Enemies Skyfall)
-- Chaos 33 (Enemies Bouncy Time)
-- Chaos 34 (Windy!)
-- Chaos 35 (Character Change 2nd roll)


-- Special Chaos:
-- Random tiles act like coins. (1 in 150 every chaos)
-- Level restart. (1 in 1250 e.c.)
-- Warp Zone randomization (1 in 4 e.c.) [1 in 45 each time, a World 9 may appear.]
-- Every time you complete a world, the next world is random. [Extreme Mode exclusive.]

require("x_functions");

if not x_requires then
	-- Sanity check. If they require a newer version, let them know.
	timer	= 1;
	while (true) do
		timer = timer + 1;
		for i = 0, 32 do
			gui.drawbox( 6, 28 + i, 250, 92 - i, "#000000");
		end;
		gui.text( 10, 32, string.format("This Lua script requires the x_functions library."));
		gui.text( 53, 42, string.format("It appears you do not have it."));
		gui.text( 39, 58, "Please get the x_functions library at");
		gui.text( 14, 69, "http://xkeeper.shacknet.nu/");
		gui.text(114, 78, "emu/nes/lua/x_functions.lua");

		warningboxcolor	= string.format("%02X", math.floor(math.abs(30 - math.fmod(timer, 60)) / 30 * 0xFF));
		gui.drawbox(7, 29, 249, 91, "#ff" .. warningboxcolor .. warningboxcolor);

		FCEU.frameadvance();
	end;

else
	emu.poweron()
	x_requires(4);
	
	LookupTable = {0x07,0x4C,0xB9,0x6E,0x16,0x0A,0x1B,0x12,0x18,0x15,0x1E,0x12,0x10,0x12,0x22,0x16,0x27,0x18,0x22,0x30,0x27,0x19,0x04,0x09,0xAC,0x53,0x07,0xB9,0xFD,0xC5,0x48,0xC8,0x84,0x00,0xA8,0xA2,0x04,0xB9,0xEB,0xC5,0x9D,0x75,0x66,0x9D,0x4A,0x6C,0x88,0xCA,0x10,0xF3,0x68,0x38,0xE5,0x00,0xA8,0xA2,0x03,0xB9,0xF5,0xC5,0x9D,0x37,0x65,0x88,0xCA,0x10,0xF6,0x60,0x20,0x84,0x01,0x44,0x20,0x85,0x57,0x48,0x20,0x9C,0x01,0x49,0x20,0xA4,0xC9,0x46,0x20,0xA5,0x57,0x26,0x20,0xBC,0xC9,0x4A,0x20,0xA5,0x0A,0xD0,0xD1,0xD8,0xD8,0xDE,0xD1,0xD0,0xDA,0xDE,0xD1,0x20,0xC5,0x17,0xD2,0xD3,0xDB,0xDB,0xDB,0xD9,0xDB,0xDC,0xDB,0xDF,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x20,0xE5,0x17,0xD4,0xD5,0xD4,0xD9,0xDB,0xE2,0xD4,0xDA,0xDB,0xE0,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x26,0x21,0x05,0x57,0x26,0x21,0x05,0x0A,0xD6,0xD7,0xD6,0xD7,0xE1,0x26,0xD6,0xDD,0xE1,0xE1,0x21,0x25,0x17,0xD0,0xE8,0xD1,0xD0,0xD1,0xDE,0xD1,0xD8,0xD0,0xD1,0x26,0xDE,0xD1,0xDE,0xD1,0xD0,0xD1,0xD0,0xD1,0x26,0x26,0xD0,0xD1,0x21,0x45,0x17,0xDB,0x42,0x42,0xDB,0x42,0xDB,0x42,0xDB,0xDB,0x42,0x26,0xDB,0x42,0xDB,0x42,0xDB,0x42,0xDB,0x42,0x26,0x26,0xDB,0x42,0x21,0x65,0x46,0xDB,0x21,0x6B,0x11,0xDF,0xDB,0xDB,0xDB,0x26,0xDB,0xDF,0xDB,0xDF,0xDB,0xDB,0xE4,0xE5,0x26,0x26,0xEC,0xED,0x21,0x85,0x17,0xDB,0xDB,0xDB,0xDE,0x43,0xDB,0xE0,0xDB,0xDB,0xDB,0x26,0xDB,0xE3,0xDB,0xE0,0xDB,0xDB,0xE6,0xE3,0x26,0x26,0xEE,0xEF,0x21,0xA5,0x17,0xDB,0xDB,0xDB,0xDB,0x42,0xDB,0xDB,0xDB,0xD4,0xD9,0x26,0xDB,0xD9,0xDB,0xDB,0xD4,0xD9,0xD4,0xD9,0xE7,0x26,0xDE,0xDA,0x21,0xC4,0x19,0x5F,0x95,0x95,0x95,0x95,0x95,0x95,0x95,0x95,0x97,0x98,0x78,0x95,0x96,0x95,0x95,0x97,0x98,0x97,0x98,0x95,0x78,0x95,0xF0,0x7A,0x21,0xEF,0x0E,0xCF,0x01,0x09,0x08,0x06,0x24,0x17,0x12,0x17,0x1D,0x0E,0x17,0x0D,0x18,0x22,0x4D,0x0A,0x16,0x0A,0x1B,0x12,0x18,0x24,0x10,0x0A,0x16,0x0E,0x22,0x8D,0x0A,0x15,0x1E,0x12,0x10,0x12,0x24,0x10,0x0A,0x16,0x0E,0x22,0xEB,0x04,0x1D,0x18,0x19,0x28,0x22,0xF5,0x01,0x00,0x23,0xC9,0x47,0x55,0x23,0xD1,0x47,0x55,0x23,0xD9,0x47,0x55,0x23,0xCC,0x43,0xF5,0x23,0xD6,0x01,0xDD,0x23,0xDE,0x01,0x5D,0x23,0xE2,0x04,0x55,0xAA,0xAA,0xAA,0x23,0xEA,0x04,0x95,0xAA,0xAA,0x2A,0x00,0xFF,0xFF,0x35,0x9D,0x55,0x9B,0xC9,0x1B,0x59,0x9D,0x45,0x9B,0xC5,0x1B,0x26,0x80,0x45,0x1B,0xB9,0x1D,0xF0,0x15,0x59,0x9D,0x0F,0x08,0x78,0x2D,0x96,0x28,0x90,0xB5,0xFF,0x74,0x80,0xF0,0x38,0xA0,0xBB,0x40,0xBC,0x8C,0x1D,0xC9,0x9D,0x05,0x9B,0x1C,0x0C,0x59,0x1B,0xB5,0x1D,0x2C,0x8C,0x40,0x15,0x7C,0x1B,0xDC,0x1D,0x6C,0x8C,0xBC,0x0C,0x78,0xAD,0xA5,0x28,0x90,0xB5,0xFF,0x0F,0x04,0x9C,0x0C,0x0F,0x07,0xC5,0x1B,0x65,0x9D,0x49,0x9D,0x5C,0x8C,0x78,0x2D,0x90,0xB5,0xFF,0x49,0x9F,0x67,0x03,0x79,0x9D,0xA0,0x3A,0x57,0x9F,0xBB,0x1D,0xD5,0x25,0x0F,0x05,0x18,0x1D,0x74,0x00,0x84,0x00,0x94,0x00,0xC6,0x29,0x49,0x9D,0xDB,0x05,0x0F,0x08,0x05,0x9B,0x09,0x1D,0xB0,0x38,0x80,0x95,0xC0,0x3C,0xEC,0xA8,0xCC,0x8C,0x4A,0x9B,0x78,0x2D,0x90,0xB5,0xFF,0x07,0x8E,0x47,0x03,0x0F,0x03,0x10,0x38,0x1B,0x80,0x53,0x06,0x77,0x0E,0x83,0x83,0xA0,0x3D,0x90,0x3B,0x90,0xB7,0x60,0xBC,0xB7,0x0E,0xEE,0x42,0x00,0xF7,0x80,0x6B,0x83,0x1B,0x83,0xAB,0x06,0xFF,0x96,0xA4,0xF9,0x24,0xD3,0x83,0x3A,0x83,0x5A,0x03,0x95,0x07,0xF4,0x0F,0x69,0xA8,0x33,0x87,0x86,0x24,0xC9,0x24,0x4B,0x83,0x67,0x83,0x17,0x83,0x56,0x28,0x95,0x24,0x0A,0xA4,0xFF,0x0F,0x02,0x47,0x0E,0x87,0x0E,0xC7,0x0E,0xF7,0x0E,0x27,0x8E,0xEE,0x42,0x25,0x0F,0x06,0xAC,0x28,0x8C,0xA8,0x4E,0xB3,0x20,0x8B,0x8E,0xF7,0x90,0x36,0x90,0xE5,0x8E,0x32,0x8E,0xC2,0x06,0xD2,0x06,0xE2,0x06,0xFF,0x15,0x8E,0x9B,0x06,0xE0,0x37,0x80,0xBC,0x0F,0x04,0x2B,0x3B,0xAB,0x0E,0xEB,0x0E,0x0F,0x06,0xF0,0x37,0x4B,0x8E,0x6B,0x80,0xBB,0x3C,0x4B,0xBB,0xEE,0x42,0x20,0x1B,0xBC,0xCB,0x00,0xAB,0x83,0xEB,0xBB,0x0F,0x0E,0x1B,0x03,0x9B,0x37,0xD4,0x0E,0xA3,0x86,0xB3,0x06,0xC3,0x06,0xFF,0xC0,0xBE,0x0F,0x03,0x38,0x0E,0x15,0x8F,0xAA,0x83,0xF8,0x07,0x0F,0x07,0x96,0x10,0x0F,0x09,0x48,0x10,0xBA,0x03,0xFF,0x87,0x85,0xA3,0x05,0xDB,0x83,0xFB,0x03,0x93,0x8F,0xBB,0x03,0xCE,0x42,0x42,0x9B,0x83,0xAE,0xB3,0x40,0xDB,0x00,0xF4,0x0F,0x33,0x8F,0x74,0x0F,0x10,0xBC,0xF5,0x0F,0x2E,0xC2,0x45,0xB7,0x03,0xF7,0x03,0xC8,0x90,0xFF,0x80,0xBE,0x83,0x03,0x92,0x10,0x4B,0x80,0xB0,0x3C,0x07,0x80,0xB7,0x24,0x0C,0xA4,0x96,0xA9,0x1B,0x83,0x7B,0x24,0xB7,0x24,0x97,0x83,0xE2,0x0F,0xA9,0xA9,0x38,0xA9,0x0F,0x0B,0x74,0x8F,0xFF,0xE2,0x91,0x0F,0x03,0x42,0x11,0x0F,0x06,0x72,0x11,0x0F,0x08,0xEE,0x02,0x60,0x02,0x91,0xEE,0xB3,0x60,0xD3,0x86,0xFF,0x0F,0x02,0x9B,0x02,0xAB,0x02,0x0F,0x04,0x13,0x03,0x92,0x11,0x60,0xB7,0x00,0xBC,0x00,0xBB,0x0B,0x83,0xCB,0x03,0x7B,0x85,0x9E,0xC2,0x60,0xE6,0x05,0x0F,0x0C,0x62,0x10,0xFF,0xE6,0xA9,0x57,0xA8,0xB5,0x24,0x19,0xA4,0x76,0x28,0xA2,0x0F,0x95,0x8F,0x9D,0xA8,0x0F,0x07,0x09,0x29,0x55,0x24,0x8B,0x17,0xA9,0x24,0xDB,0x83,0x04,0xA9,0x24,0x8F,0x65,0x0F,0xFF,0x0A,0xAA,0x1E,0x22,0x29,0x1E,0x25,0x49,0x2E,0x27,0x66,0xFF,0x0A,0x8E,0xDE,0xB4,0x00,0xE0,0x37,0x5B,0x82,0x2B,0xA9,0xAA,0x29,0x29,0xA9,0xA8,0x29,0x0F,0x08,0xF0,0x3C,0x79,0xA9,0xC5,0x26,0xCD,0x26,0xEE,0x3B,0x01,0x67,0xB4,0x0F,0x0C,0x2E,0xC1,0x00,0xFF,0x09,0xA9,0x19,0xA9,0xDE,0x42,0x02,0x7B,0x83,0xFF,0x1E,0xA0,0x0A,0x1E,0x23,0x2B,0x1E,0x28,0x6B,0x0F,0x03,0x1E,0x40,0x08,0x1E,0x25,0x4E,0x0F,0x06,0x1E,0x22,0x25,0x1E,0x25,0x45,0xFF,0x0F,0x01,0x2A,0x07,0x2E,0x3B,0x41,0xE9,0x07,0x0F,0x03,0x6B,0x07,0xF9,0x07,0xB8,0x80,0x2A,0x87,0x4A,0x87,0xB3,0x0F,0x84,0x87,0x47,0x83,0x87,0x07,0x0A,0x87,0x42,0x87,0x1B,0x87,0x6B,0x03,0xFF,0x1E,0xA7,0x6A,0x5B,0x82,0x74,0x07,0xD8,0x07,0xE8,0x02,0x0F,0x04,0x26,0x07,0xFF,0x9B,0x07,0x05,0x32,0x06,0x33,0x07,0x34,0x33,0x8E,0x4E,0x0A,0x7E,0x06,0x9E,0x0A,0xCE,0x06,0xE3,0x00,0xEE,0x0A,0x1E,0x87,0x53,0x0E,0x8E,0x02,0x9C,0x00,0xC7,0x0E,0xD7,0x37,0x57,0x8E,0x6C,0x05,0xDA,0x60,0xE9,0x61,0xF8,0x62,0xFE,0x0B,0x43,0x8E,0xC3,0x0E,0x43,0x8E,0xB7,0x0E,0xEE,0x09,0xFE,0x0A,0x3E,0x86,0x57,0x0E,0x6E,0x0A,0x7E,0x06,0xAE,0x0A,0xBE,0x06,0xFE,0x07,0x15,0xE2,0x55,0x62,0x95,0x62,0xFE,0x0A,0x0D,0xC4,0xCD,0x43,0xCE,0x09,0xDE,0x0B,0xDD,0x42,0xFE,0x02,0x5D,0xC7,0xFD,0x9B,0x07,0x05,0x32,0x06,0x33,0x07,0x34,0x03,0xE2,0x0E,0x06,0x1E,0x0C,0x7E,0x0A,0x8E,0x05,0x8E,0x82,0x8A,0x8E,0x8E,0x0A,0xEE,0x02,0x0A,0xE0,0x19,0x61,0x23,0x06,0x28,0x62,0x2E,0x0B,0x7E,0x0A,0x81,0x62,0x87,0x30,0x8E,0x04,0xA7,0x31,0xC7,0x0E,0xD7,0x33,0xFE,0x03,0x03,0x8E,0x0E,0x0A,0x11,0x62,0x1E,0x04,0x27,0x32,0x4E,0x0A,0x51,0x62,0x57,0x0E,0x5E,0x04,0x67,0x34,0x9E,0x0A,0xA1,0x62,0xAE,0x03,0xB3,0x0E,0xBE,0x0B,0xEE,0x09,0xFE,0x0A,0x2E,0x82,0x7A,0x0E,0x7E,0x0A,0x97,0x31,0xBE,0x04,0xDA,0x0E,0xEE,0x0A,0xF1,0x62,0xFE,0x02,0x3E,0x8A,0x7E,0x06,0xAE,0x0A,0xCE,0x06,0xFE,0x0A,0x0D,0xC4,0x11,0x53,0x21,0x52,0x24,0x0B,0x51,0x52,0x61,0x52,0xCD,0x43,0xCE,0x09,0xDD,0x42,0xDE,0x0B,0xFE,0x02,0x5D,0xC7,0xFD,0x5B,0x09,0x05,0x34,0x06,0x35,0x6E,0x06,0x7E,0x0A,0xAE,0x02,0xFE,0x02,0x0D,0x01,0x0E,0x0E,0x2E,0x0A,0x6E,0x09,0xBE,0x0A,0xED,0x4B,0xE4,0x60,0xEE,0x0D,0x5E,0x82,0x78,0x72,0xA4,0x3D,0xA5,0x3E,0xA6,0x3F,0xA3,0xBE,0xA6,0x3E,0xA9,0x32,0xE9,0x3A,0x9C,0x80,0xA3,0x33,0xA6,0x33,0xA9,0x33,0xE5,0x06,0xED,0x4B,0xF3,0x30,0xF6,0x30,0xF9,0x30,0xFE,0x02,0x0D,0x05,0x3C,0x01,0x57,0x73,0x7C,0x02,0x93,0x30,0xA7,0x73,0xB3,0x37,0xCC,0x01,0x07,0x83,0x17,0x03,0x27,0x03,0x37,0x03,0x64,0x3B,0x77,0x3A,0x0C,0x80,0x2E,0x0E,0x9E,0x02,0xA5,0x62,0xB6,0x61,0xCC,0x02,0xC3,0x33,0xED,0x4B,0x03,0xB7,0x07,0x37,0x83,0x37,0x87,0x37,0xDD,0x4B,0x03,0xB5,0x07,0x35,0x5E,0x0A,0x8E,0x02,0xAE,0x0A,0xDE,0x06,0xFE,0x0A,0x0D,0xC4,0xCD,0x43,0xCE,0x09,0xDD,0x42,0xDE,0x0B,0xFE,0x02,0x5D,0xC7,0xFD,0x9B,0x07,0x05,0x32,0x06,0x33,0x07,0x34,0x4E,0x03,0x5C,0x02,0x0C,0xF1,0x27,0x00,0x3C,0x74,0x47,0x0E,0xFC,0x00,0xFE,0x0B,0x77,0x8E,0xEE,0x09,0xFE,0x0A,0x45,0xB2,0x55,0x0E,0x99,0x32,0xB9,0x0E,0xFE,0x02,0x0E,0x85,0xFE,0x02,0x16,0x8E,0x2E,0x0C,0xAE,0x0A,0xEE,0x05,0x1E,0x82,0x47,0x0E,0x07,0xBD,0xC4,0x72,0xDE,0x0A,0xFE,0x02,0x03,0x8E,0x07,0x0E,0x13,0x3C,0x17,0x3D,0xE3,0x03,0xEE,0x0A,0xF3,0x06,0xF7,0x03,0xFE,0x0E,0xFE,0x8A,0x38,0xE4,0x4A,0x72,0x68,0x64,0x37,0xB0,0x98,0x64,0xA8,0x64,0xE8,0x64,0xF8,0x64,0x0D,0xC4,0x71,0x64,0xCD,0x43,0xCE,0x09,0xDD,0x42,0xDE,0x0B,0xFE,0x02,0x5D,0xC7,0xFD,0x50,0x31,0x0F,0x26,0x13,0xE4,0x23,0x24,0x27,0x23,0x37,0x07,0x66,0x61,0xAC,0x74,0xC7,0x01,0x0B,0xF1,0x77,0x73,0xB6,0x04,0xDB,0x71,0x5C,0x82,0x83,0x2D,0xA2,0x47,0xA7,0x0A,0xB7,0x29,0x4F,0xB3,0x87,0x0B,0x93,0x23,0xCC,0x06,0xE3,0x2C,0x3A,0xE0,0x7C,0x71,0x97,0x01,0xAC,0x73,0xE6,0x61,0x0E,0xB1,0xB7,0xF3,0xDC,0x02,0xD3,0x25,0x07,0xFB,0x2C,0x01,0xE7,0x73,0x2C,0xF2,0x34,0x72,0x57,0x00,0x7C,0x02,0x39,0xF1,0xBF,0x37,0x33,0xE7,0xCD,0x41,0x0F,0xA6,0xED,0x47,0xFD,0x50,0x11,0x0F,0x26,0xFE,0x10,0x47,0x92,0x56,0x40,0xAC,0x16,0xAF,0x12,0x0F,0x95,0x73,0x16,0x82,0x44,0xEC,0x48,0xBC,0xC2,0x1C,0xB1,0xB3,0x16,0xC2,0x44,0x86,0xC0,0x9C,0x14,0x9F,0x12,0xA6,0x40,0xDF,0x15,0x0B,0x96,0x43,0x12,0x97,0x31,0xD3,0x12,0x03,0x92,0x27,0x14,0x63,0x00,0xC7,0x15,0xD6,0x43,0xAC,0x97,0xAF,0x11,0x1F,0x96,0x64,0x13,0xE3,0x12,0x2E,0x91,0x9D,0x41,0xAE,0x42,0xDF,0x20,0xCD,0xC7,0xFD,0x52,0x21,0x0F,0x20,0x6E,0x64,0x4F,0xB2,0x7C,0x5F,0x7C,0x3F,0x7C,0xD8,0x7C,0x38,0x83,0x02,0xA3,0x00,0xC3,0x02,0xF7,0x16,0x5C,0xD6,0xCF,0x35,0xD3,0x20,0xE3,0x0A,0xF3,0x20,0x25,0xB5,0x2C,0x53,0x6A,0x7A,0x8C,0x54,0xDA,0x72,0xFC,0x50,0x0C,0xD2,0x39,0x73,0x5C,0x54,0xAA,0x72,0xCC,0x53,0xF7,0x16,0x33,0x83,0x40,0x06,0x5C,0x5B,0x09,0x93,0x27,0x0F,0x3C,0x5C,0x0A,0xB0,0x63,0x27,0x78,0x72,0x93,0x09,0x97,0x03,0xA7,0x03,0xB7,0x22,0x47,0x81,0x5C,0x72,0x2A,0xB0,0x28,0x0F,0x3C,0x5F,0x58,0x31,0xB8,0x31,0x28,0xB1,0x3C,0x5B,0x98,0x31,0xFA,0x30,0x03,0xB2,0x20,0x04,0x7F,0xB7,0xF3,0x67,0x8D,0xC1,0xBF,0x26,0xAD,0xC7,0xFD,0x54,0x11,0x0F,0x26,0x38,0xF2,0xAB,0x71,0x0B,0xF1,0x96,0x42,0xCE,0x10,0x1E,0x91,0x29,0x61,0x3A,0x60,0x4E,0x10,0x78,0x74,0x8E,0x11,0x06,0xC3,0x1A,0xE0,0x1E,0x10,0x5E,0x11,0x67,0x63,0x77,0x63,0x88,0x62,0x99,0x61,0xAA,0x60,0xBE,0x10,0x0A,0xF2,0x15,0x45,0x7E,0x11,0x7A,0x31,0x9A,0xE0,0xAC,0x02,0xD9,0x61,0xD4,0x0A,0xEC,0x01,0xD6,0xC2,0x84,0xC3,0x98,0xFA,0xD3,0x07,0xD7,0x0B,0xE9,0x61,0xEE,0x10,0x2E,0x91,0x39,0x71,0x93,0x03,0xA6,0x03,0xBE,0x10,0xE1,0x71,0xE3,0x31,0x5E,0x91,0x69,0x61,0xE6,0x41,0x28,0xE2,0x99,0x71,0xAE,0x10,0xCE,0x11,0xBE,0x90,0xD6,0x32,0x3E,0x91,0x5F,0x37,0x66,0x60,0xD3,0x67,0x6D,0xC1,0xAF,0x26,0x9D,0xC7,0xFD,0x54,0x11,0x0F,0x26,0xAF,0x32,0xD8,0x62,0xE8,0x62,0xF8,0x62,0xFE,0x10,0x0C,0xBE,0xF8,0x64,0x0D,0xC8,0x2C,0x43,0x98,0x64,0xAC,0x39,0x48,0xE4,0x6A,0x62,0x7C,0x47,0xFA,0x62,0x3C,0xB7,0xEA,0x62,0xFC,0x4D,0xF6,0x02,0x03,0x80,0x06,0x02,0x13,0x02,0xDA,0x62,0x0D,0xC8,0x0B,0x17,0x97,0x16,0x2C,0xB1,0x33,0x43,0x6C,0x31,0xAC,0x31,0x17,0x93,0x73,0x12,0xCC,0x31,0x1A,0xE2,0x2C,0x4B,0x67,0x48,0xEA,0x62,0x0D,0xCA,0x17,0x12,0x53,0x12,0xBE,0x11,0x1D,0xC1,0x3E,0x42,0x6F,0x20,0x4D,0xC7,0xFD,0x52,0xB1,0x0F,0x20,0x6E,0x75,0x53,0xAA,0x57,0x25,0xB7,0x0A,0xC7,0x23,0x0C,0x83,0x5C,0x72,0x87,0x01,0xC3,0x00,0xC7,0x20,0xDC,0x65,0x0C,0x87,0xC3,0x22,0xF3,0x03,0x03,0xA2,0x27,0x7B,0x33,0x03,0x43,0x23,0x52,0x42,0x9C,0x06,0xA7,0x20,0xC3,0x23,0x03,0xA2,0x0C,0x02,0x33,0x09,0x39,0x71,0x43,0x23,0x77,0x06,0x83,0x67,0xA7,0x73,0x5C,0x82,0xC9,0x11,0x07,0x80,0x1C,0x71,0x98,0x11,0x9A,0x10,0xF3,0x04,0x16,0xF4,0x3C,0x02,0x68,0x7A,0x8C,0x01,0xA7,0x73,0xE7,0x73,0xAC,0x83,0x09,0x8F,0x1C,0x03,0x9F,0x37,0x13,0xE7,0x7C,0x02,0xAD,0x41,0xEF,0x26,0x0D,0x0E,0x39,0x71,0x7F,0x37,0xF2,0x68,0x02,0xE8,0x12,0x3A,0x1C,0x00,0x68,0x7A,0xDE,0x3F,0x6D,0xC5,0xFD,0x55,0x10,0x0B,0x1F,0x0F,0x26,0xD6,0x12,0x07,0x9F,0x33,0x1A,0xFB,0x1F,0xF7,0x94,0x53,0x94,0x71,0x71,0xCC,0x15,0xCF,0x13,0x1F,0x98,0x63,0x12,0x9B,0x13,0xA9,0x71,0xFB,0x17,0x09,0xF1,0x13,0x13,0x21,0x42,0x59,0x0F,0xEB,0x13,0x33,0x93,0x40,0x06,0x8C,0x14,0x8F,0x17,0x93,0x40,0xCF,0x13,0x0B,0x94,0x57,0x15,0x07,0x93,0x19,0xF3,0xC6,0x43,0xC7,0x13,0xD3,0x03,0xE3,0x03,0x33,0xB0,0x4A,0x72,0x55,0x46,0x73,0x31,0xA8,0x74,0xE3,0x12,0x8E,0x91,0xAD,0x41,0xCE,0x42,0xEF,0x20,0xDD,0xC7,0xFD,0x52,0x21,0x0F,0x20,0x6E,0x63,0xA9,0xF1,0xFB,0x71,0x22,0x83,0x37,0x0B,0x36,0x50,0x39,0x51,0xB8,0x62,0x57,0xF3,0xE8,0x02,0xF8,0x02,0x08,0x82,0x18,0x02,0x2D,0x4A,0x28,0x02,0x38,0x02,0x48,0x00,0xA8,0x0F,0xAA,0x30,0xBC,0x5A,0x6A,0xB0,0x4F,0xB6,0xB7,0x04,0x9A,0xB0,0xAC,0x71,0xC7,0x01,0xE6,0x74,0x0D,0x09,0x46,0x02,0x56,0x00,0x6C,0x01,0x84,0x79,0x86,0x02,0x96,0x02,0xA4,0x71,0xA6,0x02,0xB6,0x02,0xC4,0x71,0xC6,0x02,0xD6,0x02,0x39,0xF1,0x6C,0x00,0x77,0x02,0xA3,0x09,0xAC,0x00,0xB8,0x72,0xDC,0x01,0x07};
	
	LevelTable = {0x00,0x01,0x03,0x04,0x00,0x01,0x02,0x03,0x00,0x01,0x03,0x04,0x00,0x01,0x02,0x03,0x00,0x01,0x03,0x04,0x00,0x01,0x03,0x04,0x00,0x01,0x02,0x03,0x00,0x01,0x02,0x03,0x00,0x00,0x00,0x00}
	
	LevelTable2 = {0x00,0x01,0x03,0x04,0x00,0x01,0x03,0x04,0x00,0x01,0x02,0x03,0x00,0x01,0x02,0x03};
	
	W9Text = {0x00,0x22,0x23,0x1A,0x0C,0x18,0x17,0x10,0x1B,0x0A,0x1D,0x1C,0x24,0x0C,0x18,0x16,0x19,0x15,0x0E,0x1D,0x12,0x17,0x10,0x24,0x20,0x08,0x28,0x04,0x2B,0x2B,0x22,0xA6,0x14,0x1D,0x0E,0x1C,0x1D,0x24,0x22,0x18,0x1E,0x1B,0x24,0x15,0x1E,0x0C,0x14,0x24,0x12,0x17,0x24,0x20,0x09,0x22,0xE6,0x14,0x05,0x24,0x15,0x12,0x1F,0x0E,0x1C,0xAF,0x24,0x16,0x18,0x1B,0x0E,0x24,0x0C,0x11,0x0A,0x18,0x1C,0x2B,0x00,0x21,0xE0,0x60,0x24,0x22,0x40,0x60,0x24,0x22,0x25,0x15,0x1D,0x11,0x0A,0x17,0x14,0x24,0x22,0x18,0x1E,0x24,0x0F,0x18,0x1B,0x24,0x19,0x15,0x0A,0x22,0x12,0x17,0x10,0x22,0x66,0x13,0x1C,0x16,0x0B,0x02,0x13,0x24,0x0C,0x11,0x0A,0x18,0x1C,0x24,0x0E,0x0D,0x12,0x1D,0x12,0x18,0x17,0x00,0xFF}
	
	HardWorlds = {"A","B","C","D","?","?","?","?"};
	
	--Images
	spr_mushroom = {16,16,"N","N","N","N","N","N","#EA9E22","#EA9E22","#EA9E22","#B53120","N","N","N","N","N","N","N","N","N","N","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#B53120","N","N","N","N","N","N","N","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#B53120","#B53120","N","N","N","N","N","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","N","N","N","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","N","N","#EA9E22","#B53120","#B53120","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","N","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#EA9E22","#B53120","#B53120","#B53120","#B53120","#B53120","#B53120","#B53120","#B53120","#EA9E22","#EA9E22","#EA9E22","#EA9E22","N","#EA9E22","#B53120","#B53120","#B53120","#FFFEFF","#B53120","#FFFEFF","#FFFEFF","#B53120","#FFFEFF","#B53120","#B53120","#B53120","#EA9E22","N","N","N","N","#B53120","#FFFEFF","#FFFEFF","#B53120","#FFFEFF","#FFFEFF","#B53120","#FFFEFF","#FFFEFF","#B53120","N","N","N","N","N","N","N","#FFFEFF","#FFFEFF","#B53120","#FFFEFF","#FFFEFF","#B53120","#FFFEFF","#FFFEFF","N","N","N","N","N","N","N","N","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#EA9E22","#FFFEFF","N","N","N","N","N","N","N","N","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#EA9E22","#FFFEFF","N","N","N","N","N","N","N","N","N","#FFFEFF","#FFFEFF","#FFFEFF","#FFFEFF","#EA9E22","#FFFEFF","N","N","N","N","N"};
	spr_flower = {16,16,"N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#FFFFFF","#FFFFFF","#FFFFFF","N","#FFFFFF","#FFFFFF","#E69C21","#E69C21","#E69C21","#B53120","#B53120","#B53120","#B53120","#B53120","#B53120","#E69C21","#E69C21","#E69C21","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#E69C21","#E69C21","#E69C21","#B53120","#B53120","#B53120","#B53120","#B53120","#B53120","#E69C21","#E69C21","#E69C21","#FFFFFF","#FFFFFF","N","#FFFFFF","#FFFFFF","#FFFFFF","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","N","N","N","#0C9300","#0C9300","N","N","N","N","N","N","N","#0C9300","#0C9300","#0C9300","N","N","N","N","#0C9300","#0C9300","N","N","N","N","#0C9300","#0C9300","#0C9300","N","#0C9300","#0C9300","#0C9300","N","N","N","#0C9300","#0C9300","N","N","N","#0C9300","#0C9300","#0C9300","N","N","#0C9300","#0C9300","#0C9300","#0C9300","N","N","#0C9300","#0C9300","N","N","#0C9300","#0C9300","#0C9300","#0C9300","N","N","N","#0C9300","#0C9300","#0C9300","#0C9300","N","#0C9300","#0C9300","N","#0C9300","#0C9300","#0C9300","#0C9300","N","N","N","N","#0C9300","#0C9300","#0C9300","#0C9300","N","#0C9300","#0C9300","N","#0C9300","#0C9300","#0C9300","#0C9300","N","N","N","N","N","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","#0C9300","N","N","N","N","N","N","N","N","N","#0C9300","#0C9300","#0C9300","#0C9300","N","N","N","N","N","N"};
	spr_star = {16,16,"N","N","N","N","N","N","N","#E69C21","#E69C21","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#E69C21","#E69C21","N","N","N","N","N","N","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#B53120","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","#E69C21","N","N","#E69C21","#E69C21","#E69C21","#E69C21","N","N","N","N","N","#E69C21","#E69C21","#E69C21","N","N","N","N","N","N","#E69C21","#E69C21","#E69C21","N","N","N","N","#E69C21","#E69C21","N","N","N","N","N","N","N","N","#E69C21","#E69C21","N","N"}
	spr_wing = {16,16,"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#FFFFFF","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","#FFFFFF","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#0C9300","#0C9300","#FFFFFF","#FFFFFF","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#0C9300","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#0C9300","#0C9300","#0C9300","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#0C9300","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","N","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"}
	spr_clock = {16,16,"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#1B1B1B","#FECCC5","#FECCC5","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#FECCC5","#FECCC5","N","N","N","N","N","#1B1B1B","#FECCC5","#FECCC5","#994E00","#994E00","#1B1B1B","#1B1B1B","#1B1B1B","#994E00","#994E00","#FECCC5","#FECCC5","N","N","N","#1B1B1B","#FECCC5","#FECCC5","#994E00","#1B1B1B","#1B1B1B","#994E00","#994E00","#994E00","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","N","N","#1B1B1B","#1B1B1B","#994E00","#1B1B1B","#994E00","#994E00","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#1B1B1B","#994E00","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#994E00","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#1B1B1B","#994E00","#994E00","#994E00","#FECCC5","#994E00","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","N","N","#1B1B1B","#1B1B1B","#994E00","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#1B1B1B","N","N","N","N","N","#1B1B1B","#1B1B1B","#994E00","#994E00","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#1B1B1B","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#994E00","#994E00","#994E00","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"}
	spr_pow = {16,16,"N","N","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","N","N","N","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","N","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#FFFFFF","#1B1B1B","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#1B1B1B","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#FFFFFF","#1B1B1B","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#FFFFFF","#FFFFFF","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","N","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","N","N","N","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","#4242FF","N","N"}
	spr_pause = {16,16,"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#B53120","#B53120","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"}
	spr_shoe = {16,16,"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#FECCC5","#FECCC5","#FECCC5","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","N","#1B1B1B","#994E00","#994E00","#994E00","#994E00","#1B1B1B","#1B1B1B","N","N","N","N","N","N","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","#1B1B1B","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","N","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","N","#1B1B1B","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","N","#1B1B1B","#1B1B1B","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","N","N","N","#1B1B1B","#FECCC5","#FECCC5","#994E00","#994E00","#994E00","#994E00","#994E00","#994E00","#1B1B1B","N","N","N","N","#FECCC5","#FECCC5","#FECCC5","#1B1B1B","#1B1B1B","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#FECCC5","#1B1B1B","N","N","N","N","N","N","N","N","N","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"}
	spr_switch = {16,16,"#9C4A00","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","N","#9C4A00","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#1B1B1B","#FFCEC5","N","#9C4A00","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#1B1B1B","N","N","#FFCEC5","N","#9C4A00","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#FFCEC5","N","#1B1B1B","N","#1B1B1B","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","N","N","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","N","N","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","N","N","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","N","N","#FFCEC5","N","#FFCEC5","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#9C4A00","N","#1B1B1B","N","#1B1B1B","#FFCEC5","N","#FFCEC5","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#9C4A00","N","#1B1B1B","N","N","#FFCEC5","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#9C4A00","N","#1B1B1B","#FFCEC5","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#9C4A00","N","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#1B1B1B","N","#9C4A00"}
	spr_bridge = {16,16,"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#1B1B1B","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","N","N","N","N","N","N","N","N","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","N","N","N","N","N","N","N","N","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5","N","N","N","N","N","N","N","N","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","N","N","N","N","N","N","N","N","#FFCEC5","#1B1B1B","#FFCEC5","#1B1B1B","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","N","N","N","N","N","N","N","N","#FFCEC5","#9C4A00","#1B1B1B","#1B1B1B","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","N","N","N","N","N","N","N","N","#FFCEC5","#1B1B1B","#9C4A00","#9C4A00","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5","N","N","N","N","N","N","N","N","#9C4A00","#FFCEC5","#1B1B1B","#FFCEC5"}
	spr_borderL = {4,16,"N","N","#0000FF","#0000FF","N","#0000FF","#0000FF","#0000FF","#0000FF","#0000FF","#0000FF","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","#0000FF","N","N","#0000FF","#0000FF","#0000FF","N","N","#0000FF","#0000FF"}
	spr_borderR = {4,16,"#0000FF","#0000FF","N","N","#0000FF","#0000FF","#0000FF","N","N","#0000FF","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","N","#0000FF","#0000FF","N","#0000FF","#0000FF","#0000FF","#0000FF","#0000FF","#0000FF","N","#0000FF","#0000FF","N","N"}
	spr_no = {1,1,"N"};
	--
	sprites = {spr_mushroom,spr_flower,spr_star,spr_wing,spr_clock,spr_pow,spr_pause,spr_shoe,spr_switch,spr_bridge};
	
	debug = 0;
	
	hy = 100;
	titimer = 0;
	titimer2 = 0;
	coinchance = 0;
	cpause = 1;
	
	title = 60;
	worldselect = 0x00;
	level = 0x00;
	
	inf = 0;
	rpress = 0;
	rpress2 = 0;
	
	world = 0;
	wtimer = 0;
	wdelay = 0;
	hard = 0;
	
	
	w1 = 0x04;
	w2 = 0x03;
	w3 = 0x02;
	
	chaostimer = 999999;
	
	chaos = 0;
	chaoscur = 0;
	extreme = 0;
	
	choose = 0;
	choose2 = 0;
	choose3 = 0;
	
	-- Music Changing (Chaos 1)
	tempo = 1;
	mult = 0;
	musictimer = 0;
	
	-- Velocity Change (Chaos 4)
	vtype = 0;
	
	-- Gravity Change (Chaos 8)
	JGrav = 0x00
	FGrav = 0x00
	GravTimer = 0;
	
	-- Enemy Portals (Chaos 10)
	portaltoggle = 0;
	
	-- Super Lakitu Toggle (Chaos 11)
	lakitu = 0;
	LTimer = 0;
	
	-- Mario Portals (Chaos 12)
	mportaltimer = 0;
	
	-- Timer Change (Chaos 13)
	timertimer = 0;										
	changetype = 1;
	th = 0;
	tt = 0;
	ts = 0;
	
	-- Frozen Movement (Chaos 14)
	freezetimer = 0;
	fvel = 0;
	
	-- Sprite Garbage (Chaos 15)
	spritetimer = 0;
	
	-- Rush (Chaos 16)
	rushtimer = 0;
	
	-- Matching Velocities (Chaos 17)
	matchtimer = 0;
	
	-- Level Restart (Chaos ??)
	rchance = 0;
	restart = 0;
	
	-- Sound Music (22)
	sfxtimer = 0;
	lastsfx = 0;
	sfx = 0;
	sfxtype = 0;
	
	-- P-Switch Mode (23)
	PTimer = 0;
	PCur = 0x00;
	
	-- Terrain Fuckery (Chaos 24)
	TrTimer = 0;
	TrPrev = 0x00;
	
	--Hamor Bruthor (Chaos 26)
	HamTimer = 0;
	
	--gay (Chaos 28)
	SebasTimer = 0;
	
	--fucking shit (Chaos 30)
	BrTimer = 0;
	
	--Enemy Bounce (Chaos 33)
	EBTimer = 0;
	
	--Windy TIme (Chaos 34)
	windtimer = 0;
	
	--Player Change (Chaos 35)
	PlayerSel = 0x00
	NameOffset = 0x00
	
	--SMB35 Roulette! (Activated with UP+B)
	roulette = 0;
	r_timer = 0;
	r_duration = 0;
	r_item = 0;
	r_chance = 0;
	r_y = 0;
	r_sw = 0;
	r_used = 0;
	b_press = 0;
	--
	SpdValues = {0xD8,0xE8,0xF0,0x28,0x18,0x10,0x0C,0xE4,0x98,0xD0};
	AltValues = {0xD8,0xE8,0xF0,0x28,0x18,0x10,0x0C,0xE4,0x98,0xD0};
	
	bridge_x1 = {0x00,0x00};
	bridge_x2 = {0x00,0x00};
	--
	chaosnum = 35; --Number of Total Chaos Events
	chaosforce = 0; --If not 0, this will force a specific chaos event.
	safetimer = 0;
	unsafetimer = 0;
	DisEvents = {0,0,0,0,0};
	
end;

function gameloop()
	
if emu.paused() == false then
--
--
choose = 0;

-- Check for Pauses
	if (memory.readbyte(0x0776) == 0x81) or (memory.readbyte(0x0776) == 0x01) then
	cpause = 1;
	end;
	if (memory.readbyte(0x0776) == 0x80) or (memory.readbyte(0x0776) == 0x00) then
	cpause = 0;
	end;
	if (memory.readbyte(0x073C) >= 0x06 and memory.readbyte(0x073C) < 0x0A) then
	cpause = 1;
	end;
	
	if (memory.readbyte(0x000E) == 0x0B) then
		memory.writebyte(0x0752,0x00);
	end;

if emu.lagged() == false then
	if (chaostimer > 0 and cpause == 0) then chaostimer = chaostimer-1; end;
end;

if (memory.readbyte(0x001D) == 0x03) then
chaostimer = 150;
end;

if chaostimer == 0 then
rchance = math.random(1,1250);
coinchance = math.random(1,150);
chaos = math.random(1,chaosnum+2);

for i=1,5 do
	if chaos == DisEvents[i] then chaos = 0; end;
end;

if chaosforce > 0 then chaos = chaosforce; end;


if wdelay == 0 then wchange = math.random(1,14); end;
if wdelay > 0 then wdelay = wdelay-1; end;
	if debug == 1 then
	if chaos <= chaosnum then
	chaoscur = chaoscur+1;
	emu.print("Running Chaos #"..chaos.." ("..chaoscur..")") ;
	end;
	if chaos > chaosnum then emu.print("No Chaos Ran") end;
	if wchange == 1 then emu.print("Warp Zones altered") end;
	if coinchance == 1 then emu.print("Coin tiles created") end;
	if rchance == 1 then emu.print("Level Restarted") end;
	end;

if wchange == 1 then --Warp Zone Randomizer
	if memory.readbyte(0x06D6) == 0x00
	then
	
	wdelay = 15;
	
	choose = 1;
	
	if choose == 1 then
	memory.writebyte(0x670c,math.random(0x01,0x08));
	memory.writebyte(0x670d,math.random(0x01,0x08));
	memory.writebyte(0x670e,math.random(0x01,0x08));
	memory.writebyte(0x670f,math.random(0x01,0x08));
	memory.writebyte(0x6710,math.random(0x01,0x08));
	memory.writebyte(0x6711,math.random(0x01,0x08));
	memory.writebyte(0x6712,math.random(0x01,0x08));
	memory.writebyte(0x6713,math.random(0x01,0x08));
	memory.writebyte(0x6714,math.random(0x0a,0x0d));
	memory.writebyte(0x6715,math.random(0x0a,0x0d));
	memory.writebyte(0x6716,math.random(0x0a,0x0d));
	end;
	
	if (choose == 1) then
		wdelay = 18;
	end;
	
	choose = 0;
	wchange = 0;
	end;
end;

-- Do the fucking shit lol

if chaos == 1 then --Music Change
	if musictimer == 0 then
		musictimer = math.random(600,1200)
		tempo = math.random(-2,3);
		if tempo == 1 then musictimer = 0; end;
	end;
end;

if chaos == 2 then --Whoops, enemies go WOOSH
for i=0,5 do
choose = 1;
	if memory.readbyte(0x0016+i) == 0x04 then choose = 0; end;
		if memory.readbyte(0x0016+i) == 0x0D then choose = 0; end;
		if memory.readbyte(0x0016+i) >= 0x1B and memory.readbyte(0x0016+i) <= 0x20 then choose = 0; end;
	if memory.readbyte(0x001E+i) == 0x00 and choose == 1 then 
	memory.writebyte(0x0058+i,math.random(0x00,0xFF));
	end;
end;
end;

if chaos == 3 then --Whoops, enemies go WEEEEEEE
	for i=0,5 do
	choose = 1;
	if memory.readbyte(0x0016+i) == 0x04 then choose = 0; end;
		if memory.readbyte(0x0016+i) == 0x0D then choose = 0; end;
		if memory.readbyte(0x0016+i) >= 0x1B and memory.readbyte(0x0016+i) <= 0x20 then choose = 0; end;
	if memory.readbyte(0x001E+i) == 0x00 and choose == 1 then 
	memory.writebyte(0x001E+i,0x01);
	memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)-0x01); end;
	memory.writebyte(0x00A0+i,math.random(0xF5,0xFC));
	end;
end;

if chaos == 4 then --Whoops, Mario go AAAAAAAA
	choose = math.random(1,2);
	vtype = math.random(1,3);
	if (vtype == 1) then
	memory.writebyte(0x0057,math.random(0x00,0xFF));
	memory.writebyte(0x0705,memory.readbyte(0x0057));
	end;
	choose = math.random(1,2);
	if (vtype == 2) then
	if choose == 1 then memory.writebyte(0x009F,math.random(0x01,0x05)); end
	if choose == 2 then memory.writebyte(0x009F,math.random(0xF8,0xFC)); end
	end;

	if (vtype == 3) then
	memory.writebyte(0x0057,math.random(0x00,0xFF));
	memory.writebyte(0x0705,memory.readbyte(0x0057));
	if choose == 1 then memory.writebyte(0x009F,math.random(0x01,0x05)); end
	if choose == 2 then memory.writebyte(0x009F,math.random(0xF8,0xFC)); end
	end;

end;

if chaos == 5 then --Oh shit, Mario toggled his swimming lol
memory.writebyte(0x0704,memory.readbyte(0x0704)+0x01);
if memory.readbyte(0x0704) == 0x02 then memory.writebyte(0x0704,0x00); end;
end;

if chaos == 6 then --Oops, level changed a bit, woahhahfdhdgfdgdgfgfd
memory.writebyte(0x0742,math.random(0x00,0xFF));
end;

if chaos == 7 then --Oops, level changed a bit, woahhahfdhdgfdgdgfgfd
memory.writebyte(0x0741,math.random(0x00,0x02));
end;

if chaos == 8 then --Gravity Changing!
	JGrav = math.random(0x10,0xFF)
	FGrav = math.random(0x01,0xB2)
	GravTimer = math.random(120,300);
end;

if chaos == 9 then --NANI?! I've teleported a block upwards or downwards!
choose = math.random(1,4);
if choose == 1 then 
	if memory.readbyte(0x00CE) <= 0x10 then
		memory.writebyte(0x00B5,memory.readbyte(0x00B5)-0x01);
	end;
memory.writebyte(0x00CE,memory.readbyte(0x00CE)-0x10); end;
if choose == 2 then memory.writebyte(0x00CE,memory.readbyte(0x00CE)+0x10); end;
if choose == 3 then 
if memory.readbyte(0x00CE) <= 0x20 then
		memory.writebyte(0x00B5,memory.readbyte(0x00B5)-0x01);
	end;
memory.writebyte(0x00CE,memory.readbyte(0x00CE)-0x20); 
end;
if choose == 4 then 
if memory.readbyte(0x00CE) <= 0x30 then
		memory.writebyte(0x00B5,memory.readbyte(0x00B5)-0x01);
	end;
memory.writebyte(0x00CE,memory.readbyte(0x00CE)-0x30); 
end;

end;

if chaos == 10 then -- Enemy Portals Activated!
portaltoggle = portaltoggle+1;
if portaltoggle == 2 then portaltoggle = 0 end;
end;

if chaos == 11 then -- Lakitu's ready to smackitu!
	if LTimer == 0 then
	lakitu = 1;
	LTimer = math.random(60,600);
	end;
end;

if chaos == 12 then --Woah, Mario won't die from pits! ... For a bit.
if mportaltimer == 0 then mportaltimer = math.random(300,1200); end;
end;

if chaos == 13 then --Sorry, someone killed the timer.. No refunds for whatever happens to it.
	if timertimer == 0 then
	timertimer = math.random(20,200);
	changetype = math.random(0,1);

	th = memory.readbyte(0x07EC);
	tt = memory.readbyte(0x07ED);
	ts = memory.readbyte(0x07EE);
		if (th + tt + ts == 0) then
		th = 4;
		tt = 0;
		ts = 0;
		end;
	end;
end;

if chaos == 14 then --Oops, slipping!
	if freezetimer == 0 then
	freezetimer = math.random(45,200);
	fvel = memory.readbyte(0x0057);
	end;
end;

if chaos == 15 then --GFFDIGFOIJOIJRIOGJOIGJ4IOGIOJOIR
	if spritetimer == 0 then
	spritetimer = math.random(1,600);
	end;
end;

if chaos == 16 then --Much Fast
	if rushtimer == 0 then
	rushtimer = math.random(300,900);
	end;
end;

if chaos == 17 then --Goomba see, Goomba do.
	if matchtimer == 0 then
	matchtimer = math.random(120, 300);
	end;
end;

if chaos == 18 then --Break Mario's body
	memory.writebyte(0x03C4,math.random(0x00,0xFF));
end;

if chaos == 19 then --Level Palette Change
memory.writebyte(0x0773,math.random(0x00,0x04));
end;

if chaos == 20 then 
choose = math.random(1,15);
local tbl2 = {0x00,0x01,0x02,0x03,0x0D,0x0F,0x11,0x13,0x34,0x60,0x75,0x79,0x81,0x88,0xA2,0xF3}
memory.writebyte(0x074E,math.random(0x00,0x03));
if choose == 1 then memory.writebyte(0x074E,tbl2[math.random(1,16)]); end;
end;

if chaos == 21 then 
--ALSO Player Change
end;

if chaos == 22 then
	local tbl4 = {0x01,0x02,0x04,0x08,0x10}
	memory.writebyte(0x00FB,tbl4[math.random(1,5)]);
end;

if chaos == 23 then -- Bouncy Mario moment
	if PTimer == 0 then
		PTimer = math.random(240,720);
	end;
end;

if chaos == 24 then --Terrain Fuckery
	if memory.readbyte(0x000E) == 0x08 then
		if TrTimer == 0 then
		TrPrev = memory.readbyte(0x0727);
		TrTimer = math.random(15,120);
		if extreme == 1 then TrTimer = math.random(60,360); end;
		end;
	end;
end;

if chaos == 25 then --Background Change
	choose = math.random(1,3);
	if (choose == 1 or choose == 3) then memory.writebyte(0x0741,math.random(0x00,0x03)); end;
	if (choose == 2 or choose == 3) then memory.writebyte(0x0742,math.random(0x00,0x0F)); end;
	
	choose = 0;
end;

if chaos == 26 then --AH FUCK HAMMER BROTHERS? WHFESDGDGHDFFD
	choose = math.random(1,3);
	if (extreme == 0 and choose == 1) then HamTimer = 5; end;
	if extreme == 1 then HamTimer = math.random(60,450); end;
end;

if chaos == 27 then --And then Chibi said "Hey put invisible blocks"
	for i=0x500,0x69F do
	choose = math.random(1,12);
	if choose == 1 then
		if memory.readbyte(i) == 0x00 then memory.writebyte(i,0x5E) end;
		end;
	end;
end;

if chaos == 28 then --Sebas said 
	choose = math.random(1,4);
		if choose == 1 then
		SebasTimer = 69;
		end;
end;

if chaos == 29 then --fuck
	for i=0,5 do
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then memory.writebyte(0x0016+i,math.random(0x23,0x2C)); end;
	end;
end;

if chaos == 30 then -- Pretend P-Switch thingy
	if BrTimer == 0 then
		BrTimer = math.random(120,480);
		end;
	for i=0x500,0x69F do
		if (memory.readbyte(i) >= 0x50 and memory.readbyte(i) <= 0x54) then
			choose = math.random(1,25);
			if choose == 1 then
			memory.writebyte(i,math.random(0x55,0x60)) end;
		end;
	end;
end;

if chaos == 31 then -- Scroll Stop!
	if memory.readbyte(0x0723) == 0x00 then
		sfxtimer = math.random(90,200);
	end;
end;

if chaos == 32 then -- Enemies fall from the sky like woah!!!!
	for i=0,4 do
		if (memory.readbyte(0x000F+i) == 0x00) then
		local tbl3 = {0x00, 0x02, 0x03, 0x05, 0x06, 0x0A, 0x0b, 0x0c, 0x0e, 0x12, 0x14}
		memory.writebyte(0x0016+i,tbl3[math.random(1,11)]);
		memory.writebyte(0x000F+i,0x01);
		memory.writebyte(0x001E+i,0x00);
		memory.writebyte(0x00A0+i,0x04);
		memory.writebyte(0x00B6+i,0x00);
		memory.writebyte(0x00CF+i,math.random(0xD8,0xE8));
		if memory.readbyte(0x0016+i) == 0x05 then
		memory.writebyte(0x00B6+i,0x01);
		memory.writebyte(0x00CF+i,0x00);
		end;
		if memory.readbyte(0x0016+i) == 0x06 then
		memory.writebyte(0x001E+i,0x01);
		end;
		memory.writebyte(0x006E+i,memory.readbyte(0x006D));
		local EX = 0;
		EX = memory.readbyte(0x0086) + 256;
		EX = EX + math.random(-120,220);
		if EX > 512 then memory.writebyte(0x006E+i,memory.readbyte(0x006E+i)+0x01); end;
		if EX < 256 then memory.writebyte(0x006E+i,memory.readbyte(0x006E+i)+0x01); end;
		memory.writebyte(0x0087+i,EX-256);
		choose = math.random(1,2);
			if choose == 1 then
			memory.writebyte(0x0058+i,0xF8);
			memory.writebyte(0x0046+i,0x02);
			else
			memory.writebyte(0x0058+i,0x08);
			memory.writebyte(0x0046+i,0x01);
			end;
		end;
	end;
end;

if chaos == 33 then -- Enemy Bounce Time
	if EBTimer == 0 then
		EBTimer = math.random(240,720);
	end;
end;

if chaos == 34 then -- WINDDDDD (When possible)
	if windtimer == 0 then
		windtimer = math.random(240,900);
	end;
end;

if chaos == 35 or chaos == 21 then -- Player Change
	if memory.readbyte(0x07A0) == 0x00 then
		choose = math.random(1,16);
		PlayerSel = math.random(0x00,0x01);
		if choose == 1 then
			PlayerSel = math.random(0x00,0xFF);
		end;
		NameOffset = LookupTable[0x17+PlayerSel];
			--Name Patch
			for i=0x00,0x04 do
				memory.writebyte(0x6679-i,LookupTable[0x05+NameOffset-i]);
				memory.writebyte(0x6C4E-i,LookupTable[0x05+NameOffset-i]);
			end;
			--Palette Patch
			for i=0x00,0x03 do
				memory.writebyte(0x6537+i,LookupTable[0x0F+(PlayerSel*4)+i]);
			end;
		memory.writebyte(0x0753,PlayerSel);
	end;
end;

if coinchance == 1 then --Random Coin Spots
choose2 = math.random(1,15);
if debug == 1 then
	if choose2 == 1 then emu.print("Everything is coins! OH FUCK SHIT BI-") end;
end;
for i=0x500,0x69F do
choose = math.random(1,9);
if choose2 == 1 then choose = 1 end;
	if choose == 1 then
	if memory.readbyte(i) > 0x00 then memory.writebyte(i,0xC3) end;
	end;
end;
end;

if rchance == 1 then
	memory.writebyte(0x0712,0x01);
	memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01);
	memory.writebyte(0x00B5,0x06);
end;

-- reset timer
chaostimer = math.random(45,240);

if memory.readbyte(0x075F) == 0x07 then
	if memory.readbyte(0x075C) == 0x03 then
	chaostimer = math.floor(chaostimer*1.75);
	else
	chaostimer = math.floor(chaostimer*1.25);
	end;
end;

if memory.readbyte(0x075F) == 0x08 then chaostimer = math.floor(chaostimer/2) end;

if chaos == 0 then chaostimer = 1; end;
end;

if title > 0 then
title = title-1;
end;

if title == 0 then
	if joyin['select'] then
	if memory.readbyte(0x000E) == 0x04 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	if memory.readbyte(0x000E) == 0x05 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	if memory.readbyte(0x000E) == 0x07 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	
	memory.writebyte(0x0743,0x00);
	memory.writebyte(0x0752,0x00);
	memory.writebyte(0x0751,0x00);
	memory.writebyte(0x0712,0x01);
	memory.writebyte(0x075b,0x00);
	memory.writebyte(0x07B1,0x00);
	memory.writebyte(0x000E,0x08);
	memory.writebyte(0x00B5,0x06);
	
	title = 150;
	end;
end;

-- Stuff below is what specific chaos code does.

if memory.readbyte(0x00CE) < 0x10 and memory.readbyte(0x000E) == 0x07 then
	memory.writebyte(0x000E,0x08);
	memory.writebyte(0x00cE,0x20);
end;

if inf >= 2 then
memory.writebyte(0x075A,0x04);
inf = inf+1;
	if inf >= 60 then
	inf = 0;
	end;
end;

if memory.readbyte(0x075F) == 0x08 and memory.readbyte(0x07F7) == 0x02 then
	if memory.readbyte(0xC97F) == 0x18 then
	choose = 2;
	inf = 2;
	chaostimer = 480;
		while (choose > 0) do
		memory.writebyte(0xC97B+choose,W9Text[choose]);
		choose = choose+1;
			if W9Text[choose] == 0xFF then
				choose = 0;
			end;
		end;
	memory.writebyte(0x075A,0x04);
	memory.writebyte(0x609C,0xC9);
	end;
end;

if inf == 1 then -- Infinite Lives
choose = 1
if memory.readbyte(0x075F) == 0x07 and memory.readbyte(0x07F7) == 0x02 then
choose = 0;
memory.writebyte(0x075A,0xFF);
end;
	if choose == 1 then
	memory.writebyte(0x075A,0x08);
	if lifeframe == 2 and memory.readbyte(0x00FE) == 0x00 then lifeframe = 0; end;
	if memory.readbyte(0x00FE) >= 0x40 and memory.readbyte(0x00FE) <= 0x7F then
		lifeframe = 1
	end;
	if memory.readbyte(0x00FE) >= 0xC0 and memory.readbyte(0x00FE) <= 0xFF then
		lifeframe = 1
	end;
	if lifeframe == 1 then
		lifeframe = 2;
		if unsafetimer == 0 then
		safetimer = safetimer+480;
		memory.writebyte(0x079F,0x05);
		memory.writebyte(0x00FB,0x10);
		end;
		if safetimer > (60*30) then
		safetimer = 0;
		unsafetimer = 600;
		end;
	end;
	end;
end;

memory.writebyte(0x07FA,0xFF);

if memory.readbyte(0xC506) == 0xC9 then
	memory.writebyte(0xC507,memory.readbyte(0x074E));
end;

if (memory.readbyte(0x000E) >= 0x04 and memory.readbyte(0x000E) <= 0x05) then
	for i=0x500,0x69F do
		if (memory.readbyte(i) == 0xC2) then memory.writebyte(i,0x51) end;
	end;
end;

if r_item == 9 and roulette < 3 then
memory.writebyte(0xA9D9,0xC9);
r_item = 0;
end;

if r_used == 1 then
memory.writebyte(0x7C47,0xAD);
memory.writebyte(0x7C48,0x4E);
memory.writebyte(0x7C49,0x07);
r_used = 0;
end;

if cpause == 0 and title == 0 then
		if roulette == 3 then
			if r_duration > 0 then
				r_duration = r_duration-1;		
				DisEvents = {0,0,0,0,0};
				
				if r_item == 4 then
					DisEvents = {8,4,23,5,0};
					PTimer = 0;
					if memory.readbyte(0x0704) == 0x00 then
					memory.writebyte(0x0709,0x12);
					memory.writebyte(0x070A,0x0C);
					end;
				end;
				if r_item == 6 then
				DisEvents = {17,2,3,0,0};
				matchtimer = 0;
				end;
				if r_item == 7 then
					if r_duration/60 == math.floor(r_duration/60) then memory.writebyte(0x00fe,0x10); end;
					matchtimer = 0;
					timertimer = 0;
					if sfxtimer > 1 then sfxtimer = 1; end;
					DisEvents = {17,2,3,13,0};
					PTimer = 0;
					memory.writebyte(0x0747,0x03);
					memory.writebyte(0x0785,0x00);
				end;
				if r_item == 8 then
					rushtimer = 0;
					freezetimer = 0;
					DisEvents = {16,14,21,35,31};
					for i=1,7 do
						memory.writebyte(0x7FAE+i,AltValues[i]);
					end;
					for i=1,3 do
						memory.writebyte(0x7F9D+i,AltValues[i+7]);
					end;
					if r_duration == 0 then
						for i=1,7 do
						memory.writebyte(0x7FAE+i,SpdValues[i]);
						end;
						for i=1,3 do
							memory.writebyte(0x7F9D+i,SpdValues[i+7]);
						end;
					end;
				end;
				if r_item == 9 then
					freezetimer = 0;
					DisEvents = {14,0,0,0,0};
					if memory.readbyte(0x000E) == 0x08 then
						memory.writebyte(0xA9D9,0x60);
					else
						memory.writebyte(0xA9D9,0xC9);
					end;
				end;
				if r_item == 10 then
						if (r_duration/2 == math.floor(r_duration/2)) and r_duration >= 80 then
							if r_duration < 117 then
								if bridge_x1[2] == 0x00 then
								if bridge_x1[1] == 0x00 then bridge_x1[1] = 0x01; end;
								bridge_x1[1]=bridge_x1[1]-0x01;
								bridge_x1[2]=0x10;
								end;
								bridge_x1[2]=bridge_x1[2]-0x01;
								bridge_x2[2]=bridge_x2[2]+0x01;
								if bridge_x2[2] == 0x10 then
								bridge_x2[1]=bridge_x2[1]+0x01;
								bridge_x2[2]=0x00;
								end;	
							end;
								local did = 0;
								local base = 0x05D0;
								if bridge_x1[1]/2 == math.floor(bridge_x1[1]/2) then base = 0x0500; end;
								
								if memory.readbyte(base+0xB0+bridge_x1[2]) == 0x00 then
								did = 1;
								memory.writebyte(0x03E6,bridge_x1[2]+(base-0x0500));
								memory.writebyte(0x03E4,0xB0);
								memory.writebyte(0x03EA,bridge_x1[1]);
								memory.writebyte(0x03EC,0x01);
								memory.writebyte(0x03E8,0x89);
								end;
								base = 0x05D0;
								if bridge_x2[1]/2 == math.floor(bridge_x2[1]/2) then base = 0x0500; end;
								if memory.readbyte(base+0xB0+bridge_x2[2]) == 0x00 then
								did = 1;
								memory.writebyte(0x03E7,bridge_x2[2]+(base-0x0500));
								memory.writebyte(0x03E5,0xB0);
								memory.writebyte(0x03EB,bridge_x2[1]);
								memory.writebyte(0x03ED,0x01);
								memory.writebyte(0x03E9,0x89);
								end;
								
								if did == 1 then
									memory.writebyte(0x00fD,0x01);
									memory.writebyte(0x00fE,0x08);
									memory.writebyte(0x00fF,0x02);
								end;
						end;
						if r_duration >= 80 then					
							chaostimer = chaostimer+1;
						
						end;
						if r_duration < 80 then
							r_item = 10.1;
							r_duration = 600;
						end;
				end;
				if r_item == 10.1 then
					
					bridge_x1 = {memory.readbyte(0x006D),math.floor(memory.readbyte(0x0086)/0x10)};
					
					bridge_x1[2] = bridge_x1[2]+1;
					if bridge_x1[2] >= 0x10 then
					bridge_x1[1]=bridge_x1[1]+1;
					bridge_x1[2]=bridge_x1[2]-0x10;
					end;
						local did = 0;
								local base = 0x05D0;
								if bridge_x1[1]/2 == math.floor(bridge_x1[1]/2) then base = 0x0500; end;
								
								if memory.readbyte(base+0xB0+bridge_x1[2]) == 0x00 then
								did = 1;
								memory.writebyte(0x03E6,bridge_x1[2]+(base-0x0500));
								memory.writebyte(0x03E4,0xB0);
								memory.writebyte(0x03EA,bridge_x1[1]);
								memory.writebyte(0x03EC,0x01);
								memory.writebyte(0x03E8,0x89);
								end;
								
								if did == 1 then
									memory.writebyte(0x00fD,0x01);
									memory.writebyte(0x00fE,0x08);
									memory.writebyte(0x00fF,0x02);
									did = 0;
								end;
				end;
				
				if r_y < 0 then r_y=r_y+1; end;
				if r_sw <= 0 then r_sw=r_sw+5; end;
				if r_duration < 180 then r_sw=r_sw-1; end;
				if r_duration < 120 then r_sw=r_sw-1; end;
				if r_duration < 80 then r_sw=r_sw-1; end;
				if r_duration < 40 then r_sw=r_sw-1; end;
				if r_duration == 0 then roulette = 0; end;
			end;
		end;
		
		if roulette == 2 then
			choose = math.random(1,100);
			if r_duration == 0 then
				roulette = 3;
				r_y = r_y-6;
				r_sw = 1;
				r_item = 1;
				if choose >= 16 then r_item = 2; end;
				if choose >= 26 then r_item = 3; end;
				if choose >= 34 then r_item = 4; end;
				if choose >= 45 then r_item = 5; end;
				if choose >= 55 then r_item = 6; end;
				if choose >= 70 then r_item = 7; end;
				if choose >= 75 then r_item = 8; end;
				if choose >= 83 then r_item = 9; end;
				if choose >= 92 then r_item =10; end;
				if r_item == 1 then
				r_duration = 140;
				if memory.readbyte(0x0756) == 0x01 then memory.writebyte(0x0756,0x00); memory.writebyte(0x00fe,0x10); end;
				memory.writebyte(0x0014,0x01);
				memory.writebyte(0x001B,0x2e);
				memory.writebyte(0x0023,0xC0);
				memory.writebyte(0x0039,0x00);
				
				memory.writebyte(0x0073,memory.readbyte(0x006D));
				memory.writebyte(0x008C,memory.readbyte(0x0086));
				memory.writebyte(0x00BB,memory.readbyte(0x00B5));
				memory.writebyte(0x00D4,memory.readbyte(0x00CE));
				memory.writebyte(0x00A5,memory.readbyte(0x009F));
				end;
				if r_item == 2 then
				r_duration = 140;
				memory.writebyte(0x0756,0x01);
				memory.writebyte(0x0014,0x01);
				memory.writebyte(0x001B,0x2e);
				memory.writebyte(0x0023,0xC0);
				memory.writebyte(0x0039,0x01);
				
				memory.writebyte(0x0073,memory.readbyte(0x006D));
				memory.writebyte(0x008C,memory.readbyte(0x0086));
				memory.writebyte(0x00BB,memory.readbyte(0x00B5));
				memory.writebyte(0x00D4,memory.readbyte(0x00CE));
				memory.writebyte(0x00A5,memory.readbyte(0x009F));
				end;
				if r_item == 3 then
				r_duration = 140;
				memory.writebyte(0x0014,0x01);
				memory.writebyte(0x001B,0x2e);
				memory.writebyte(0x0023,0xC0);
				memory.writebyte(0x0039,0x02);
				
				memory.writebyte(0x0073,memory.readbyte(0x006D));
				memory.writebyte(0x008C,memory.readbyte(0x0086));
				memory.writebyte(0x00BB,memory.readbyte(0x00B5));
				memory.writebyte(0x00D4,memory.readbyte(0x00CE));
				memory.writebyte(0x00A5,memory.readbyte(0x009F));
				end;
				if r_item == 4 then
				r_duration = 720;
				memory.writebyte(0x00ff,0x40);
				end;
				if r_item == 5 then
				r_duration = 180;
				timertimer = 120;
				changetype = 1
				th = memory.readbyte(0x07EC);
				tt = memory.readbyte(0x07ED);
				ts = memory.readbyte(0x07EE);
				end;
				if r_item == 6 then
				r_duration = 120;
				for i=0,4 do
					if memory.readbyte(0x000F+i) > 0x00 then
					memory.writebyte(0x001E+i,0xFF);
					end;
				end;
				memory.writebyte(0x00ff,0x08);
				memory.writebyte(0x00fe,0x80);
				portaltoggle = 0;
				end;
				if r_item == 7 then
				r_duration = 480;
				memory.writebyte(0x00fe,0x10);
				end;
				if r_item == 8 then
				r_duration = 1080;
					for i=1,7 do
						SpdValues[i]=memory.readbyte(0x7FAE+i);
						if SpdValues[i] > 0x7F then
						AltValues[i]=0x100-SpdValues[i];
						AltValues[i]=math.floor(AltValues[i]*1.5);
						AltValues[i]=0x100-AltValues[i];
						end;
						if SpdValues[i] <= 0x7F then
						AltValues[i]=math.floor(SpdValues[i]*1.5);
						end;
					end;
					for i=1,3 do
						SpdValues[i+7]=memory.readbyte(0x7F9D+i);
						if SpdValues[8]==0xE4 then AltValues[i+7]=0xFF; end;
						if SpdValues[8]==0xB4 then AltValues[i+7]=0xE0; end;
					end;
				end;
				if r_item == 9 then
					r_duration = 480;
					memory.writebyte(0x00ff,0x04);
				end;
				if r_item == 10 then
					r_duration = 120;
					bridge_x1 = {memory.readbyte(0x006D),math.floor(memory.readbyte(0x0086)/0x10)};
					bridge_x2 = {memory.readbyte(0x006D),math.floor(memory.readbyte(0x0086)/0x10)};
				end;
			end;
		end;
		
		if roulette == 1 then
			if memory.readbyte(0x073C) >= 0x06 and memory.readbyte(0x073C) < 0x0A then
			--no
			else
				if memory.readbyte(0x000E) == 0x08 then
				--
				else
				if r_timer < 15 then r_timer = r_timer+1; end;
				end;
				if r_timer > 0 then r_timer=r_timer-1; end;
				if r_y < 0 then r_y=r_y+2; end;
				if r_sw > 0 then
				r_sw=r_sw-1;
					if r_sw == 0 then
					r_item = math.random(1,10);
					r_sw = 3;
					if memory.readbyte(0x000E) == 0x08 then memory.writebyte(0x00ff,0x08); end;
					end;
				end;
				if r_timer == 0 then
				roulette = 2;
				memory.writebyte(0x00fe,0x02);
				end;
			end;
		end;
		
		if roulette == 0 then
		
				choose = 0;
				if (memory.readbyte(0x07E0) >= 0x05) then choose = 1 end;
				if (memory.readbyte(0x07DF) >= 0x01) then choose = 1 end;
				if (memory.readbyte(0x07DE) >= 0x01) then choose = 1 end;
				if (memory.readbyte(0x07DD) >= 0x01) then choose = 1 end;
				if memory.readbyte(0x073C) >= 0x06 and memory.readbyte(0x073C) < 0x0A then choose = 0 end;
				if choose == 1 then
					gui.opacity(0.6);
					text(114,8, "[UP+B]");
					gui.opacity(1);
				end;
			joyin = joypad.read(1);
			if (joyin['up'] and joyin['B'] and b_press == 0) then
				local e_score = 0;
				if memory.readbyte(0x07E0) >= 0x05 then e_score = 1; end;
				if memory.readbyte(0x07DD) + memory.readbyte(0x07DE) + memory.readbyte(0x07DF) >= 0x01 then
					e_score = 1;
					if memory.readbyte(0x07E0) < 0x05 then
						if memory.readbyte(0x07DF) == 0x00 then
							memory.writebyte(0x07DF,0x0A);
							
							if memory.readbyte(0x07DE) == 0x00 then
								memory.writebyte(0x07DE,0x0A);
								memory.writebyte(0x07DD,memory.readbyte(0x07DD)-0x01);
							end;
							memory.writebyte(0x07DE,memory.readbyte(0x07DE)-0x01);
							
						end;
						memory.writebyte(0x07DF,memory.readbyte(0x07DF)-0x01);
						memory.writebyte(0x07E0,memory.readbyte(0x07E0)+0x0A);
					end;
				end;
				if e_score == 1 then
					memory.writebyte(0x07E0,memory.readbyte(0x07E0)-0x05);
					roulette = 1;
					r_y = -40;
					r_timer = 90;
					r_duration = 0;
					r_item = 0;
					r_sw = 1;
					
					memory.writebyte(0x7C47,0x20);
					memory.writebyte(0x7C48,0xED);
					memory.writebyte(0x7C49,0x87);
					r_used = 1;
				else
				memory.writebyte(0x00ff,0x02);
				end;
			end;
			if joyin['B'] then
			b_press = 1;
			else
			b_press = 0;
			end;
			
		end;
end;

if title == 0 and roulette > 0 then
	choose = 1;
	if memory.readbyte(0x073C) >= 0x06 and memory.readbyte(0x073C) < 0x0A then choose = 0 end;
	
	if choose == 1 then
		if roulette == 3 then
			if r_sw > 0 then
			drawimg(spr_borderL,116,r_y+32);
			drawimg(spr_borderR,136,r_y+32);
			--gui.opacity(0.5);
			--gui.box(120, r_y+32, 135, r_y+47, "#020202");
			--gui.opacity(1);
			if r_item > 0 then drawimg(sprites[math.floor(r_item)],120,r_y+32); end;
			end;
		else
			drawimg(spr_borderL,116,r_y+32);
			drawimg(spr_borderR,136,r_y+32);
			--gui.opacity(0.5);
			--gui.box(120, r_y+32, 135, r_y+47, "#020202");
			--gui.opacity(1);
			if r_item > 0 then drawimg(sprites[math.floor(r_item)],120,r_y+32); end;
		end;
	end;
end;

if cpause == 0 and title == 0 then --AAAAA

	-- Music Changing (Chaos 1)
	if musictimer > 0 then
		musictimer = musictimer-1;
		if tempo > 1 then
		mult = tempo-1;
		end;
		if tempo < 1 then
			if mult > 0 then
			mult = mult-1;
			if memory.readbyte(0x07b4) > 0x01 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)+1);
			end;
			if memory.readbyte(0x07b6) > 0x01 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)+1);
			end;
			if memory.readbyte(0x07b9) > 0x01 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)+1);							
			end;
			if memory.readbyte(0x07ba) > 0x01 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)+1);
			end;
			else
			mult = (tempo-1)*-1;
			end;
		end;
		if tempo == 2 then
			if memory.readbyte(0x07b4) > 0x01 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)-1);
			end;
			if memory.readbyte(0x07b6) > 0x01 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)-1);
			end;
			if memory.readbyte(0x07b9) > 0x01 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)-1);							
			end;
			if memory.readbyte(0x07ba) > 0x01 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)-1);
			end;
		end;
		if tempo > 2 then
			while (mult > 0) do
			mult = mult-1;
			if memory.readbyte(0x07b4) > 0x02 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)-1);
			else
			memory.writebyte(0x07b4,0x01);
			end;
			if memory.readbyte(0x07b6) > 0x02 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)-1);
			else
			memory.writebyte(0x07b6,0x01);
			end;
			if memory.readbyte(0x07b9) > 0x02 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)-1);
			else
			memory.writebyte(0x07b9,0x01);
			end;
			if memory.readbyte(0x07ba) > 0x02 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)-1);
			else
			memory.writebyte(0x07ba,0x01);
			end;
			end;
		end;
	end;
	
	-- Gravity Change (Chaos 8)
	if GravTimer >= 1 then
		if memory.readbyte(0x0704) == 0x00 then
		GravTimer = GravTimer-1;
		memory.writebyte(0x0709,JGrav);
		memory.writebyte(0x070A,FGrav);
		else
		GravTimer = 0;
		end;
	end;
	
	-- Enemy Portals (Chaos 10)
	if portaltoggle == 1 then
		for i=0,5 do
			if memory.readbyte(0x00B6+i) == 0x02 then
			memory.writebyte(0x00B6+i,0x01);
			end;
		end;
	end;
	
	-- Super Lakitu (Chaos 11)
	if lakitu == 1 then
		if LTimer > 0 then
		LTimer = LTimer-1;
		memory.writebyte(0x078F,0x00);
		else
		lakitu = 0;
		end;
	end;
	
	-- Mario Portals (Chaos 12)
	if mportaltimer > 0 then
		mportaltimer = mportaltimer-1;
		if (memory.readbyte(0x000E) == 0x0B) then
			mportaltimer = 0;
		end;
		if (memory.readbyte(0x00CE) > 0xF0) and (memory.readbyte(0x00B5) == 0x01) then
		memory.writebyte(0x00CE,0x00);
		memory.writebyte(0x00B5,0x01);
		end;
	end;
	
	-- Time Change (Chaos 13)
	if timertimer > 0 then
		if (memory.readbyte(0x000E) == 0x08) then
			timertimer = timertimer-1;
			memory.writebyte(0x0787,0x00);
			memory.writebyte(0x07FA,memory.readbyte(0x07FA)+0x01);
			if changetype == 0 then
			ts=ts-1;
				if ts < 0 then
				tt=tt-1;
				ts=ts+10;
				end;
				if tt < 0 then
				th=th-1;
				tt=tt+10;
				end;
				if th < 0 then
				th = 0;
				tt = 0;
				ts = 0;
				end;
			memory.writebyte(0x07EC,th);
			memory.writebyte(0x07ED,tt);
			memory.writebyte(0x07EE,ts);
			memory.writebyte(0x00fe,0x10);
			end;
			if changetype == 1 then
			ts=ts+1;
				if ts > 9 then
				tt=tt+1;
				ts=ts-10;
				end;
				if tt > 9 then
				th=th+1;
				tt=tt-10;
				end;
				if th > 9 then
				th = 9;
				tt = 9;
				ts = 9;
				timertimer = 0;
				end;
			memory.writebyte(0x07EC,th);
			memory.writebyte(0x07ED,tt);
			memory.writebyte(0x07EE,ts+1);
			memory.writebyte(0x00fe,0x10);
			end;
			if ((memory.readbyte(0x07EC) + memory.readbyte(0x07ED) + memory.readbyte(0x07EE)) == 0x00) then
			timertimer = 0
			end;
		end;
	end;
	
	-- Frozen Velocity (Chaos 14)
	if freezetimer > 0 then
	freezetimer = freezetimer-1;
	memory.writebyte(0x0057,fvel);
	end;
	
	-- Sprite Garbage (Chaos 15)
	if spritetimer > 0 then
	spritetimer = spritetimer-1;
	choose = math.random(1,2);
		if choose == 1 then
		memory.writebyte(0x06D5,math.random(0x00,0xFF));
		memory.writebyte(0x070C,0x01);
		memory.writebyte(0x070D,math.random(0x00,0xFF));
		end;
	end;
	
	-- Rush (Chaos 16)
	if rushtimer > 0 then
	rushtimer = rushtimer-1;
	memory.writebyte(0x0057,memory.readbyte(0x0057)+memory.readbyte(0x0057));
	end;
	
	-- Matching Velocities (Chaos 17)
	if matchtimer > 0 then
	matchtimer = matchtimer-1;
		for i=0,5 do
		choose = 1;
		choose2 = 1;
		if memory.readbyte(0x0016+i) == 0x04 then choose = 0; end;
		if memory.readbyte(0x0016+i) == 0x0D then choose = 0; end;
		if memory.readbyte(0x0016+i) >= 0x1B and memory.readbyte(0x0016+i) <= 0x20 then choose2 = 0; end;
			if choose == 1 then
				if choose2 == 1 then memory.writebyte(0x00A0+i,0x00); end;
				memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)+memory.readbyte(0x009F));
			end;
		end;
	end;
	
	-- Bouncy Mario (Chaos 23)
	if PTimer > 0 then
			PTimer = PTimer-1;
			if (memory.readbyte(0x001D) == 0x00) and (memory.readbyte(0x000E) == 0x08) then
				joyin = joypad.read(1);
				if joyin['A'] then
				memory.writebyte(0x009F,math.random(0xF3,0xF8));
				else
				memory.writebyte(0x009F,math.random(0xFA,0xFF));
				end;
			end;
	end;
	
	-- Terrain Fuckery (Chaos 24)
	if TrTimer > 0 then
		if (memory.readbyte(0x0057) >= 0x01 and memory.readbyte(0x0057) < 0x4F and memory.readbyte(0x07A0) == 0x00) then
			TrTimer = TrTimer-1;
			choose = math.random(1,3);
			if choose == 1 then memory.writebyte(0x0727,math.random(0x00,0xFF));
			else memory.writebyte(0x0727,TrPrev); end;
			if TrTimer == 0 then memory.writebyte(0x0727,TrPrev); end;
		end;
	end;
	
	-- bitch (Chaos 26)
	if HamTimer > 0 then
		HamTimer = HamTimer-1;
		for i=0,5 do
		choose3 = 1;
		
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) >= 0x30 and memory.readbyte(0x0016+i) <= 0x34) then choose3 = 0; end;
		
		if choose3 == 1 then memory.writebyte(0x0016+i,0x05); end;
		end;
	end;
	
	-- who the fuck (Chaos 28)
	if SebasTimer > 0 then
		SebasTimer = SebasTimer-1;
		for i=0,2 do
		choose3 = 1;
		
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) >= 0x30 and memory.readbyte(0x0016+i) <= 0x34) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) == 0x07) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) == 0x11) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) == 0x12) then choose3 = 0; end;
		
		if choose3 == 1 then
			memory.writebyte(0x0016+i,0x11);
			memory.writebyte(0x0058+i,0x00);
			memory.writebyte(0x00A0+i,0x00);
			memory.writebyte(0x001E+i,0x00);
			end;
		end;
	end;
	
	-- Block SCRAMBLERRRR (Chaos 30)
	if BrTimer > 0 then
		BrTimer = BrTimer-1;
		for i=0x500,0x69F do
			if (memory.readbyte(i) >= 0xC0 and memory.readbyte(i) <= 0xC2) then
				memory.writebyte(i,math.random(0xC0,0xC2)) end;
			if (memory.readbyte(i) >= 0x52 and memory.readbyte(i) <= 0x5d) then
				memory.writebyte(i,math.random(0x52,0x5d)) end;
			if (memory.readbyte(i) >= 0x5E and memory.readbyte(i) <= 0x61) then
				memory.writebyte(i,math.random(0x5E,0x61)) end;
		end;
	end;
	
	-- Scroll Stop! (Chaos 31)
	if sfxtimer > 0 then
	sfxtimer = sfxtimer-1;
		if sfxtimer > 1 then
			memory.writebyte(0x0723,0x01);
		else
			memory.writebyte(0x0723,0x00);
		end;
	end;
	
	-- Bouncy Enemies (Chaos 33)
	if EBTimer > 0 then
		EBTimer = EBTimer-1;
		for i=0,4 do
			choose = 0;
				if memory.readbyte(0x0016+i) == (0x00) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x02) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x03) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x05) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x06) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x12) then choose = 1 end;
				if memory.readbyte(0x0016+i) == (0x24) then choose = 1 end;
			if choose == 1 then
				if memory.readbyte(0x001E+i) == 0x00 then
				memory.writebyte(0x001E+i,0x01);
				memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)-0x02);
				memory.writebyte(0x00A0+i,math.random(0xFB,0xFD));
				memory.writebyte(0x0434+i,math.random(0xFB,0xFD));
				end;
			end;
		end;
	end;
	--Wind Time (Chaos 34)
	if windtimer > 0 then
	windtimer = windtimer-1;
		if windtimer > 1 then
			memory.writebyte(0x07f9,0x01);
		else
			memory.writebyte(0x07f9,0x00);
		end;
	end;
	
end;
--AAAA
--
--
end;

	-- Title Screen
	joyin = joypad.read(1);
	if titimer > 0 then titimer=titimer-1; end;
	if titimer2 > 0 then titimer2=titimer2-1; end;
	
	if (memory.readbyte(0x0770) == 0x00) then
	chaostimer = math.random(45,120);
	safetimer = 0;
	memory.writebyte(0x07a2,0x1a);
	
	if memory.readbyte(0x000e) == 0x08 then
	roulette = 0;
	title = 120;
	gui.text(160, 52,"CHAOS", "#F5BAA2", "#F55515");
	gui.text(156.5, 52,"\nEDITION", "#F5BAA2", "#F55515");
	gui.text(112, 121,"  By TheCyVap | 2022    ", "#FFFFFF", "#5C94FC");
	gui.text(204, 36,"v2.2", "#F5BAA2", "#F55515");
	gui.box(70, 169, 186, 183, "#F55515", "#202020");
	gui.box(72, 171, 184, 181, "#F55515", "#F5BAA2");
	gui.text(77, 173,"INFINITE LIVES:", "#F5BAA2", "#F55515");
	if inf == 0 then gui.text(162, 173,"OFF", "#F5BAA2", "#F55515"); end;
	if inf == 1 then gui.text(168, 173,"ON", "#F5BAA2", "#F55515"); end;
	gui.text(86, 185," Press [RIGHT]   \n   to toggle.", "#FFFFFF", "#5C94FC");
	
	if inf == 0 then -- Infinite Lives
	memory.writebyte(0x075A,0x04);
	end;
	
	gui.box(0, 206, 256, 256, "#222222", "#222222");
	gui.text(25, 207,"Hold [UP] to see the description/help.\n[B] to select world. [A] to select level.\n[DOWN] to switch between W1-8 and WA-D.", "#FFFFFF", "#222222");
	
	
	gui.box(0, 128+hy, 256, 256, "#F55515", "#444444");
	gui.text(96,128+hy+3,"DESCRIPTION:", "#F5BAA2", "#F55515");
	gui.text(12,128+hy+13,"Random events happen during gameplay.\nYou cannot control what, or when things happen.\nAll you can do is keep going, and hope you're\nlucky.\n(Completing World 8-4 will always grant\naccess to World 9!)\n \n[SELECT] - Quick Restart (Costs 1 life)\n[UP + B] - Chaos Roulette (Costs 5000 pts.)", "#F5BAA2", "#F55515");
	gui.box(145, 23, 188, 32, "#5C94FC");
	if hard == 0 then gui.text(153, 24,(worldselect+1), "#FFFFFF", "#5C94FC"); end;
	if hard == 1 then gui.text(153, 24,HardWorlds[worldselect+1], "#FFFFFF", "#5C94FC"); end;
	gui.text(161, 24,"-", "#FFFFFF", "#5C94FC");
	gui.text(169, 24,level+1, "#FFFFFF", "#5C94FC");
	gui.box(145, 32, 188, 32, "#fcbcb4");
	if titimer == 0 then
		if joyin['B'] then 
		worldselect = worldselect+0x01;
		titimer = 15;
		if worldselect > (0x07) then worldselect = 0x00; end;
		if worldselect > 0x03 and hard == 1 then worldselect = 0x00; end;
		end;
		if worldselect == 0x08 then level = 0x00; end;
	end;
	if titimer2 == 0 and worldselect < 0x08 then
	if joyin['A'] then 
		level = level+0x01;
		titimer2 = 15;
		if level > 0x03 then level = 0x00; end;
		end;
	end;
	memory.writebyte(0x075f,worldselect);
	memory.writebyte(0x075C,level);
	if hard == 0 then memory.writebyte(0x0760,LevelTable[((worldselect*4)+level)+1]); end;
	if hard == 1 then memory.writebyte(0x0760,LevelTable2[((worldselect*4)+level)+1]); end;
	memory.writebyte(0x07FB,hard);
	if joyin['right'] then 
		if rpress == 0 then
		inf = inf+1;
		if inf == 2 then inf = 0; end;
		end;
		rpress = 1;
	else
		rpress = 0;
	end;
	if joyin['down'] then 
		if rpress2 == 0 then
		hard = hard+1;
		if hard == 2 then hard = 0; end;
		worldselect = 0x00;
		levelselect = 0x00;
		end;
		rpress2 = 1;
	else
		rpress2 = 0;
	end;
	
	if joyin['up'] then 
	hy = hy - 8;
	if hy < -0 then
	hy = 0;	
	end;
	end;
	if hy < 128 then
	hy = hy + 4;
	end;
	end;
end;
	if safetimer > 0 and cpause == 0 then
	local safe = math.ceil(safetimer/60);
	safetimer = safetimer-1;
	chaostimer = chaostimer+1;
	if sfxtimer > 1 then sfxtimer = 1; end;
	PTimer = 0;
	freezetimer = 0;
	spritetimer = 0;
	rushtimer = 0;
	matchtimer = 0;
	EBTimer = 0;
	GravTimer = 0;
	text(24,16, "CHAOS PAUSE: "..safe.."s");
	memory.writebyte(0x079F,0x09);
	if safetimer <= 10 then memory.writebyte(0x079F,0x04); end;
	end;
	
	if unsafetimer > 0 and cpause == 0 then
	local safe = math.ceil(unsafetimer/60);
	unsafetimer = unsafetimer-1;
	if chaostimer > 2 then chaostimer = 2; end;
	text(24,16, "CHAOS OVERLOAD!! ("..safe.."s)");
	memory.writebyte(0x079F,0x00);
	end;
	
	-- Debug shit
	if debug == 1 then
	text(8,8, "Timer:"..chaostimer);
	end;
end;
	
gui.register(gameloop);
--
function drawimg(image,x,y)
local width  = image[1];
local height = image[2];
local draw = 1;

	for i=0,height-1 do
		draw = 1;
		if y+i > 255 then draw = 0; end;
		if y+i < 0 then draw = 0; end;
		
		if draw == 1 then
			for ii=0,width-1 do
				if x+ii > 255 then draw = 0; end;
				if x+ii < 0 then draw = 0; end;
				if draw == 1 then
					if image[3+(ii+(i*width))] == "N" then
					--no lol
					else
					gui.pixel(x+ii, y+i, image[3+(ii+(i*width))]);
					end;
				end;
			end;
		end;
	end;

end;

--
while (true) do 
	FCEU.frameadvance();
end;