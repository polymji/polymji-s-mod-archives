--SMB1: Chaos Edition

-- Normal Chaos:
-- Chaos  1 (Music Tempo Changing)
-- Chaos  2 (Enemies WOOSH)
-- Chaos  3 (Enemies WEEEE)
-- Chaos  4 (Mario Velocity Change)
-- Chaos  5 (Swim Toggle)
-- Chaos  6 (Level Change #1)
-- Chaos  7 (Level Change #2)
-- Chaos  8 (Gravity Change)
-- Chaos  9 (Mario Teleportation)
-- Chaos 10 (Enemy Portals)
-- Chaos 11 (Lakitu/Bowser Super Saiyan Mode)
-- Chaos 12 (Mario Portals)
-- Chaos 13 (Timer Changes)
-- Chaos 14 (Frozen Velocity)
-- Chaos 15 (Sprite Fuckery)
-- Chaos 16 (Instant Acceleration + Jitters)
-- Chaos 17 (Enemies match Mario Velocity)
-- Chaos 18 (Mario's sprite alters)
-- Chaos 19 (Level Palette Change)
-- Chaos 20 (Level "Location" Change)
-- Chaos 21 (WHOOO'S THAT POWERUP?!)
-- Chaos 22 (Music Change)
-- Chaos 23 (Mario Bouncy!)
-- Chaos 24 (Terrain Fuckery)
-- Chaos 25 (Background Change)
-- Chaos 26 (Bud's Nightmare)
-- Chaos 27 (Kaizo, bitch || random Invisible coin blocks) (fuck you chibi)
-- Chaos 28 (IT'S ME, TOAAADDDDDDDDDD HAAAHAA)
-- Chaos 29 (Oops, my platorms broke)
-- Chaos 30 (Block Scrambler)
-- Chaos 31 (Scroll Stop for a few moments!)
-- Chaos 32 (Enemies Skyfall)
-- Chaos 33 (Enemies Bouncy Time)


-- Special Chaos:
-- Random tiles act like coins. (1 in 150 every chaos)
-- Level restart. (1 in 1250 e.c.)
-- Warp Zone randomization (1 in 4 e.c.) [1 in 45 each time, a World 9 may appear.]
-- Every time you complete a world, the next world is random. [Extreme Mode exclusive.]

require("x_functions");

if not x_requires then
	-- Sanity check. If they require a newer version, let them know.
	timer	= 1;
	while (true) do
		timer = timer + 1;
		for i = 0, 32 do
			gui.drawbox( 6, 28 + i, 250, 92 - i, "#000000");
		end;
		gui.text( 10, 32, string.format("This Lua script requires the x_functions library."));
		gui.text( 53, 42, string.format("It appears you do not have it."));
		gui.text( 39, 58, "Please get the x_functions library at");
		gui.text( 14, 69, "http://xkeeper.shacknet.nu/");
		gui.text(114, 78, "emu/nes/lua/x_functions.lua");

		warningboxcolor	= string.format("%02X", math.floor(math.abs(30 - math.fmod(timer, 60)) / 30 * 0xFF));
		gui.drawbox(7, 29, 249, 91, "#ff" .. warningboxcolor .. warningboxcolor);

		FCEU.frameadvance();
	end;

else
	emu.poweron()
	x_requires(4);
	
	debug = 0;
	hy = 100;
	titimer = 0;
	coinchance = 0;
	cpause = 1;
	
	title = 60;
	
	inf = 0;
	rpress = 0;
	
	world = 0;
	wtimer = 0;
	wdelay = 0;
	
	w1 = 0x04;
	w2 = 0x03;
	w3 = 0x02;
	
	chaostimer = math.random(300,600);
	
	chaos = 0;
	chaoscur = 0;
	extreme = 0;
	
	choose = 0;
	choose2 = 0;
	choose3 = 0;
	
	-- Music Changing (Chaos 1)
	tempo = 1;
	mult = 0;
	musictimer = 0;
	
	-- Velocity Change (Chaos 4)
	vtype = 0;
	
	-- Gravity Change (Chaos 8)
	JGrav = 0x00
	FGrav = 0x00
	GravTimer = 0;
	
	-- Enemy Portals (Chaos 10)
	portaltoggle = 0;
	
	-- Super Lakitu Toggle (Chaos 11)
	lakitu = 0;
	LTimer = 0;
	
	-- Mario Portals (Chaos 12)
	mportaltimer = 0;
	
	-- Timer Change (Chaos 13)
	timertimer = 0;										
	changetype = 1;
	th = 0;
	tt = 0;
	ts = 0;
	
	-- Frozen Movement (Chaos 14)
	freezetimer = 0;
	fvel = 0;
	
	-- Sprite Garbage (Chaos 15)
	spritetimer = 0;
	
	-- Rush (Chaos 16)
	rushtimer = 0;
	
	-- Matching Velocities (Chaos 17)
	matchtimer = 0;
	
	-- Level Restart (Chaos ??)
	rchance = 0;
	restart = 0;
	
	-- Sound Music (22)
	sfxtimer = 0;
	lastsfx = 0;
	sfx = 0;
	sfxtype = 0;
	
	-- P-Switch Mode (23)
	PTimer = 0;
	PCur = 0x00;
	
	-- Terrain Fuckery (Chaos 24)
	TrTimer = 0;
	TrPrev = 0x00;
	
	--Hamor Bruthor (Chaos 26)
	HamTimer = 0;
	
	--gay (Chaos 28)
	SebasTimer = 0;
	
	--fucking shit (Chaos 30)
	BrTimer = 0;
	
	--Enemy Bounce (Chaos 33)
	EBTimer = 0;
	--
	chaosnum = 33; --Number of Total Chaos Events
	chaosforce = 0; --If not 0, this will force a specific chaos event.
	safetimer = 0;
	
end;

function gameloop()
	
if emu.paused() == false then
--
--
choose = 0;
-- Check for Pauses
	if (memory.readbyte(0x0776) == 0x81) or (memory.readbyte(0x0776) == 0x01) then
	cpause = 1;
	end;
	if (memory.readbyte(0x0776) == 0x80) or (memory.readbyte(0x0776) == 0x00) then
	cpause = 0;
	end;

if emu.lagged() == false then
	if (chaostimer > 0 and cpause == 0) then chaostimer = chaostimer-1; end;
end;

if (memory.readbyte(0x001D) == 0x03) then
chaostimer = 150;
end;

if chaostimer == 0 then
rchance = math.random(1,1250);
coinchance = math.random(1,150);
chaos = math.random(1,chaosnum+3);

if chaosforce > 0 then chaos = chaosforce; end;


if wdelay == 0 then wchange = math.random(1,4); end;
if wdelay > 0 then wdelay = wdelay-1; end;
	if debug == 1 then
	if chaos <= chaosnum then
	chaoscur = chaoscur+1;
	emu.print("Running Chaos #"..chaos.." ("..chaoscur..")") ;
	end;
	if chaos > chaosnum then emu.print("No Chaos Ran") end;
	if wchange == 1 then emu.print("Warp Zones altered") end;
	if coinchance == 1 then emu.print("Coin tiles created") end;
	if rchance == 1 then emu.print("Level Restarted") end;
	end;

if wchange == 1 then --Warp Zone Randomizer
	if memory.readbyte(0x06D6) == 0x00
	then
	
	wdelay = 15;
	
	choose = math.random(1,45);
	choose2 = math.random(1,45);
	choose3 = math.random(1,45);
	
	w1 = math.random(0x01,0x08);
	if choose == 1 then w1 = math.random(0x09); end;
	w2 = math.random(0x01,0x08);
	if choose2 == 1 then w2 = math.random(0x09); end;
	w3 = math.random(0x01,0x08);
	if choose3 == 1 then w3 = math.random(0x09); end;
	
	if (choose == 1) or (choose2 == 1) or (choose3 == 1) then
		wdelay = 18;
	end;
	
	if debug == 1 then
		if (choose == 1) or (choose2 == 1) or (choose3 == 1) then
		emu.print("A World 9 created!")
		end;
	end;
	
	choose = 0;
	
	--Set Warps (hopefully)
	rom.writebyte(0x0802,w1);
	rom.writebyte(0x080A,w1);

	rom.writebyte(0x0803,w2);
	rom.writebyte(0x0807,w2);
	rom.writebyte(0x080B,w2);

	rom.writebyte(0x0804,w3);
	rom.writebyte(0x080C,w3);
	end;
	wchange = 0;
end;

-- Do the fucking shit lol

if chaos == 1 then --Music Change
	if musictimer == 0 then
		musictimer = math.random(600,1200)
		tempo = math.random(-2,3);
		if tempo == 1 then musictimer = 0; end;
	end;
end;

if chaos == 2 then --Whoops, enemies go WOOSH
for i=0,5 do
memory.writebyte(0x0058+i,math.random(0x00,0xFF));
end;
end;

if chaos == 3 then --Whoops, enemies go WEEEEEEE
	for i=0,5 do
	if memory.readbyte(0x001E+i) == 0x00 then memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)-0x01); end;
	memory.writebyte(0x00A0+i,math.random(0xF5,0xFC));
	end;
end;

if chaos == 4 then --Whoops, Mario go AAAAAAAA
	choose = math.random(1,2);
	vtype = math.random(1,3);
	if (vtype == 1) then
	memory.writebyte(0x0057,math.random(0x00,0xFF));
	memory.writebyte(0x0705,memory.readbyte(0x0057));
	end;
	choose = math.random(1,2);
	if (vtype == 2) then
	if choose == 1 then memory.writebyte(0x009F,math.random(0x01,0x05)); end
	if choose == 2 then memory.writebyte(0x009F,math.random(0xF8,0xFC)); end
	end;

	if (vtype == 3) then
	memory.writebyte(0x0057,math.random(0x00,0xFF));
	memory.writebyte(0x0705,memory.readbyte(0x0057));
	if choose == 1 then memory.writebyte(0x009F,math.random(0x01,0x05)); end
	if choose == 2 then memory.writebyte(0x009F,math.random(0xF8,0xFC)); end
	end;

end;

if chaos == 5 then --Oh shit, Mario toggled his swimming lol
memory.writebyte(0x0704,memory.readbyte(0x0704)+0x01);
if memory.readbyte(0x0704) == 0x02 then memory.writebyte(0x0704,0x00); end;
end;

if chaos == 6 then --Oops, level changed a bit, woahhahfdhdgfdgdgfgfd
memory.writebyte(0x0773,math.random(0x00,0xFF));
end;

if chaos == 7 then --Oops, level changed a bit, woahhahfdhdgfdgdgfgfd
memory.writebyte(0x074F,math.random(0x00,0xFF));
memory.writebyte(0x076F,math.random(0x00,0x08));
end;

if chaos == 8 then --Gravity Changing!
	JGrav = math.random(0x10,0xFF)
	FGrav = math.random(0x01,0xB2)
	GravTimer = math.random(120,300);
end;

if chaos == 9 then --NANI?! I've teleported a block upwards or downwards!
choose = math.random(1,2);
if choose == 1 then memory.writebyte(0x00CE,memory.readbyte(0x00CE)-0x10); end;
if choose == 2 then memory.writebyte(0x00CE,memory.readbyte(0x00CE)+0x10); end;
end;

if chaos == 10 then -- Enemy Portals Activated!
portaltoggle = portaltoggle+1;
if portaltoggle == 2 then portaltoggle = 0 end;
end;

if chaos == 11 then -- Lakitu's ready to smackitu!
	if LTimer == 0 then
	lakitu = 1;
	LTimer = math.random(60,600);
	end;
end;

if chaos == 12 then --Woah, Mario won't die from pits! ... For a bit.
if mportaltimer == 0 then mportaltimer = math.random(300,1200); end;
end;

if chaos == 13 then --Sorry, someone killed the timer.. No refunds for whatever happens to it.
	if timertimer == 0 then
	timertimer = math.random(20,200);
	changetype = math.random(0,1);

	th = memory.readbyte(0x07F8);
	tt = memory.readbyte(0x07F9);
	ts = memory.readbyte(0x07FA);
		if (th + tt + ts == 0) then
		th = 4;
		tt = 0;
		ts = 0;
		end;
	end;
end;

if chaos == 14 then --Oops, slipping!
	if freezetimer == 0 then
	freezetimer = math.random(45,200);
	fvel = memory.readbyte(0x0057);
	end;
end;

if chaos == 15 then --GFFDIGFOIJOIJRIOGJOIGJ4IOGIOJOIR
	if spritetimer == 0 then
	spritetimer = math.random(1,600);
	end;
end;

if chaos == 16 then --Much Fast
	if rushtimer == 0 then
	rushtimer = math.random(300,900);
	end;
end;

if chaos == 17 then --Goomba see, Goomba do.
	if matchtimer == 0 then
	matchtimer = math.random(120, 300);
	end;
end;

if chaos == 18 then --Break Mario's body
	memory.writebyte(0x03C4,math.random(0x00,0xFF));
end;

if chaos == 19 then --Level Palette Change
memory.writebyte(0x0773,math.random(0x00,0x04));
end;

if chaos == 20 then 
choose = math.random(1,15);
local tbl2 = {0x00,0x01,0x02,0x03,0x07,0x09,0x0B,0x0D,0x0F,0x11,0x13,0x15,0x17,0x1B,0x1D,0x1F,0x29,0x34,0x45,0x60,0x75,0x81,0xA2,0xA4,0xEF,0xF3,0xFB}
memory.writebyte(0x074E,math.random(0x00,0x03));
if choose == 1 then memory.writebyte(0x074E,tbl2[math.random(1,27)]); end;
end;

if chaos == 21 then 
memory.writebyte(0x0754,math.random(0x00,0x01));
memory.writebyte(0x0756,math.random(0x00,0x02));
end;

if chaos == 22 then
	local tbl4 = {0x01,0x02,0x04,0x08,0x10}
	memory.writebyte(0x00FB,tbl4[math.random(1,5)]);
end;

if chaos == 23 then -- Bouncy Mario moment
	if PTimer == 0 then
		PTimer = math.random(240,720);
	end;
end;

if chaos == 24 then --Terrain Fuckery
	if memory.readbyte(0x000E) == 0x08 then
		if TrTimer == 0 then
		TrPrev = memory.readbyte(0x0727);
		TrTimer = math.random(15,120);
		if extreme == 1 then TrTimer = math.random(60,360); end;
		end;
	end;
end;

if chaos == 25 then --Background Change
	choose = math.random(1,3);
	if (choose == 1 or choose == 3) then memory.writebyte(0x0741,math.random(0x00,0x03)); end;
	if (choose == 2 or choose == 3) then memory.writebyte(0x0742,math.random(0x00,0x0F)); end;
	
	choose = 0;
end;

if chaos == 26 then --AH FUCK HAMMER BROTHERS? WHFESDGDGHDFFD
	choose = math.random(1,3);
	if (extreme == 0 and choose == 1) then HamTimer = 5; end;
	if extreme == 1 then HamTimer = math.random(60,450); end;
end;

if chaos == 27 then --And then Chibi said "Hey put invisible blocks"
	for i=0x500,0x69F do
	choose = math.random(1,12);
	if choose == 1 then
		if memory.readbyte(i) == 0x00 then memory.writebyte(i,0x5F) end;
		end;
	end;
end;

if chaos == 28 then --Sebas said 
	choose = math.random(1,4);
		if choose == 1 then
		SebasTimer = 69;
		end;
end;

if chaos == 29 then --fuck
	for i=0,5 do
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then memory.writebyte(0x0016+i,math.random(0x23,0x2C)); end;
	end;
end;

if chaos == 30 then -- Pretend P-Switch thingy
	if BrTimer == 0 then
		BrTimer = math.random(120,480);
		end;
	for i=0x500,0x69F do
		if (memory.readbyte(i) >= 0x50 and memory.readbyte(i) <= 0x54) then
			choose = math.random(1,25);
			if choose == 1 then
			memory.writebyte(i,math.random(0x55,0x60)) end;
		end;
	end;
end;

if chaos == 31 then -- Scroll Stop!
	if memory.readbyte(0x0723) == 0x00 then
		sfxtimer = math.random(90,200);
	end;
end;

if chaos == 32 then -- Enemies fall from the sky like woah!!!!
	for i=0,4 do
		if (memory.readbyte(0x000F+i) == 0x00) then
		local tbl3 = {0x00, 0x01, 0x02, 0x03, 0x04, 0x06, 0x07, 0x14, 0x0C, 0x0E, 0x12}
		memory.writebyte(0x0016+i,tbl3[math.random(1,11)]);
		memory.writebyte(0x000F+i,0x01);
		memory.writebyte(0x001E+i,0x00);
		memory.writebyte(0x00A0+i,0x04);
		memory.writebyte(0x00B6+i,0x00);
		memory.writebyte(0x00CF+i,math.random(0xA0,0xE0));
		memory.writebyte(0x006E+i,memory.readbyte(0x006D));
		local EX = 0;
		EX = memory.readbyte(0x0086) + 256;
		EX = EX + math.random(-120,220);
		if EX > 512 then memory.writebyte(0x006E+i,memory.readbyte(0x006E+i)+0x01); end;
		if EX < 256 then memory.writebyte(0x006E+i,memory.readbyte(0x006E+i)+0x01); end;
		memory.writebyte(0x0087+i,EX-256);
		choose = math.random(1,2);
			if choose == 1 then
			memory.writebyte(0x0058+i,0xF8);
			memory.writebyte(0x0046+i,0x02);
			else
			memory.writebyte(0x0058+i,0x08);
			memory.writebyte(0x0046+i,0x01);
			end;
		end;
	end;
end;

if chaos == 33 then -- Enemy Bounce Time
	if EBTimer == 0 then
		EBTimer = math.random(240,720);
	end;
end;

if coinchance == 1 then --Random Coin Spots
choose2 = math.random(1,15);
if debug == 1 then
	if choose2 == 1 then emu.print("Everything is coins! OH FUCK SHIT BI-") end;
end;
for i=0x500,0x69F do
choose = math.random(1,9);
if choose2 == 1 then choose = 1 end;
	if choose == 1 then
	if memory.readbyte(i) > 0x00 then memory.writebyte(i,0xC2) end;
	end;
end;
end;

if rchance == 1 then
	memory.writebyte(0x0712,0x01);
	memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01);
	memory.writebyte(0x00B5,0x06);
end;

-- reset timer
chaostimer = math.random(25,250);
end;

if wtimer > 0 then
wtimer = wtimer-1;
memory.writebyte(0x074E,0x01);
if world == 0 then memory.writebyte(0x0750,0x25); end;
if world == 1 then memory.writebyte(0x0750,0x28); end;
if world == 2 then memory.writebyte(0x0750,0x24); end;
if world == 3 then memory.writebyte(0x0750,0x22); end;
if world == 4 then memory.writebyte(0x0750,0x2A); end;
if world == 5 then memory.writebyte(0x0750,0x2E); end;
if world == 6 then memory.writebyte(0x0750,0x33); end;
if world == 7 then memory.writebyte(0x0750,0x30); end;

end;

if title > 0 then
title = title-1;
end;

if title == 0 then
	if joyin['select'] then
	if memory.readbyte(0x000E) == 0x04 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	if memory.readbyte(0x000E) == 0x05 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	if memory.readbyte(0x000E) == 0x07 then memory.writebyte(0x075A,memory.readbyte(0x075A)+0x01); end;
	
	memory.writebyte(0x0712,0x01);
	memory.writebyte(0x075b,0x00);
	memory.writebyte(0x000E,0x08);
	memory.writebyte(0x00B5,0x06);
	
	title = 150;
	end;
end;

-- Stuff below is what specific chaos code does.

if inf == 1 then -- Infinite Lives
memory.writebyte(0x075A,0x08);
	if lifeframe == 2 and memory.readbyte(0x00FE) == 0x00 then lifeframe = 0; end;
	if memory.readbyte(0x00FE) >= 0x40 and memory.readbyte(0x00FE) <= 0x7F then
		lifeframe = 1
	end;
	if memory.readbyte(0x00FE) >= 0xC0 and memory.readbyte(0x00FE) <= 0xFF then
		lifeframe = 1
	end;
	if lifeframe == 1 then
		lifeframe = 2;
		safetimer = safetimer+600;
		memory.writebyte(0x079F,0x05);
		memory.writebyte(0x00FB,0x10);
	end;
end;

if (memory.readbyte(0x000E) >= 0x04 and memory.readbyte(0x000E) <= 0x05) then
	for i=0x500,0x69F do
		if (memory.readbyte(i) == 0xC2) then memory.writebyte(i,0x51) end;
	end;
end;

if cpause == 0 then --AAAAA
	-- Music Changing (Chaos 1)
	if musictimer > 0 then
		musictimer = musictimer-1;
		if tempo > 1 then
		mult = tempo-1;
		end;
		if tempo < 1 then
			if mult > 0 then
			mult = mult-1;
			if memory.readbyte(0x07b4) > 0x01 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)+1);
			end;
			if memory.readbyte(0x07b6) > 0x01 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)+1);
			end;
			if memory.readbyte(0x07b9) > 0x01 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)+1);							
			end;
			if memory.readbyte(0x07ba) > 0x01 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)+1);
			end;
			else
			mult = (tempo-1)*-1;
			end;
		end;
		if tempo == 2 then
			if memory.readbyte(0x07b4) > 0x01 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)-1);
			end;
			if memory.readbyte(0x07b6) > 0x01 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)-1);
			end;
			if memory.readbyte(0x07b9) > 0x01 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)-1);							
			end;
			if memory.readbyte(0x07ba) > 0x01 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)-1);
			end;
		end;
		if tempo > 2 then
			while (mult > 0) do
			mult = mult-1;
			if memory.readbyte(0x07b4) > 0x02 then
			memory.writebyte(0x07b4,memory.readbyte(0x07b4)-1);
			else
			memory.writebyte(0x07b4,0x01);
			end;
			if memory.readbyte(0x07b6) > 0x02 then
			memory.writebyte(0x07b6,memory.readbyte(0x07b6)-1);
			else
			memory.writebyte(0x07b6,0x01);
			end;
			if memory.readbyte(0x07b9) > 0x02 then
			memory.writebyte(0x07b9,memory.readbyte(0x07b9)-1);
			else
			memory.writebyte(0x07b9,0x01);
			end;
			if memory.readbyte(0x07ba) > 0x02 then
			memory.writebyte(0x07ba,memory.readbyte(0x07ba)-1);
			else
			memory.writebyte(0x07ba,0x01);
			end;
			end;
		end;
	end;
	
	-- Gravity Change (Chaos 8)
	if GravTimer >= 1 then
		if memory.readbyte(0x0704) == 0x00 then
		GravTimer = GravTimer-1;
		memory.writebyte(0x0709,JGrav);
		memory.writebyte(0x070A,FGrav);
		else
		GravTimer = 0;
		end;
	end;
	
	-- Enemy Portals (Chaos 10)
	if portaltoggle == 1 then
		for i=0,5 do
			if memory.readbyte(0x00B6+i) == 0x02 then
			memory.writebyte(0x00B6+i,0x01);
			end;
		end;
	end;
	
	-- Super Lakitu (Chaos 11)
	if lakitu == 1 then
		if LTimer > 0 then
		LTimer = LTimer-1;
		memory.writebyte(0x078F,0x00);
		else
		lakitu = 0;
		end;
	end;
	
	-- Mario Portals (Chaos 12)
	if mportaltimer > 0 then
		mportaltimer = mportaltimer-1;
		if (memory.readbyte(0x000E) == 0x0B) then
			mportaltimer = 0;
		end;
		if (memory.readbyte(0x00CE) > 0xF0) and (memory.readbyte(0x00B5) == 0x01) then
		memory.writebyte(0x00CE,0x00);
		memory.writebyte(0x00B5,0x01);
		end;
	end;
	
	-- Time Change (Chaos 13)
	if timertimer > 0 then
		if (memory.readbyte(0x000E) == 0x08) then
			timertimer = timertimer-1;
			memory.writebyte(0x0787,0x00);
			memory.writebyte(0x07FA,memory.readbyte(0x07FA)+0x01);
			if changetype == 0 then
			ts=ts-1;
				if ts < 0 then
				tt=tt-1;
				ts=ts+10;
				end;
				if tt < 0 then
				th=th-1;
				tt=tt+10;
				end;
				if th < 0 then
				th = 0;
				tt = 0;
				ts = 0;
				end;
			memory.writebyte(0x07F8,th);
			memory.writebyte(0x07F9,tt);
			memory.writebyte(0x07FA,ts);
			memory.writebyte(0x00fe,0x10);
			end;
			if changetype == 1 then
			ts=ts+1;
				if ts > 9 then
				tt=tt+1;
				ts=ts-10;
				end;
				if tt > 9 then
				th=th+1;
				tt=tt-10;
				end;
				if th > 9 then
				th = 0;
				end;
			memory.writebyte(0x07F8,th);
			memory.writebyte(0x07F9,tt);
			memory.writebyte(0x07FA,ts+1);
			memory.writebyte(0x00fe,0x10);
			end;
			if ((memory.readbyte(0x07F8) + memory.readbyte(0x07F9) + memory.readbyte(0x07FA)) == 0x00) then
			timertimer = 0
			end;
		end;
	end;
	
	-- Frozen Velocity (Chaos 14)
	if freezetimer > 0 then
	freezetimer = freezetimer-1;
	memory.writebyte(0x0776,0x00);
	memory.writebyte(0x0057,fvel);
	end;
	
	-- Sprite Garbage (Chaos 15)
	if spritetimer > 0 then
	spritetimer = spritetimer-1;
	choose = math.random(1,2);
		if choose == 1 then
		memory.writebyte(0x06D5,math.random(0x00,0xFF));
		memory.writebyte(0x070C,0x01);
		memory.writebyte(0x070D,math.random(0x00,0xFF));
		end;
	end;
	
	-- Rush (Chaos 16)
	if rushtimer > 0 then
	rushtimer = rushtimer-1;
	memory.writebyte(0x0057,memory.readbyte(0x0057)+memory.readbyte(0x0057));
	end;
	
	-- Matching Velocities (Chaos 17)
	if matchtimer > 0 then
	matchtimer = matchtimer-1;
		for i=0,5 do
		memory.writebyte(0x00A0+i,0x00);
		memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)+memory.readbyte(0x009F));
		end;
	end;
	
	-- Bouncy Mario (Chaos 23)
	if PTimer > 0 then
			PTimer = PTimer-1;
			if (memory.readbyte(0x001D) == 0x00) and (memory.readbyte(0x000E) == 0x08) then
				joyin = joypad.read(1);
				if joyin['A'] then
				memory.writebyte(0x009F,math.random(0xF3,0xF8));
				else
				memory.writebyte(0x009F,math.random(0xFA,0xFF));
				end;
			end;
	end;
	
	-- Terrain Fuckery (Chaos 24)
	if TrTimer > 0 then
		if (memory.readbyte(0x0057) >= 0x01 and memory.readbyte(0x0057) < 0x4F and memory.readbyte(0x07A0) == 0x00) then
			TrTimer = TrTimer-1;
			choose = math.random(1,3);
			if choose == 1 then memory.writebyte(0x0727,math.random(0x00,0xFF));
			else memory.writebyte(0x0727,TrPrev); end;
			if TrTimer == 0 then memory.writebyte(0x0727,TrPrev); end;
		end;
	end;
	
	-- bitch (Chaos 26)
	if HamTimer > 0 then
		HamTimer = HamTimer-1;
		for i=0,5 do
		choose3 = 1;
		
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) >= 0x30 and memory.readbyte(0x0016+i) <= 0x34) then choose3 = 0; end;
		
		if choose3 == 1 then memory.writebyte(0x0016+i,0x05); end;
		end;
	end;
	
	-- who the fuck (Chaos 28)
	if SebasTimer > 0 then
		SebasTimer = SebasTimer-1;
		for i=0,5 do
		choose3 = 1;
		
		if (memory.readbyte(0x0016+i) >= 0x23 and memory.readbyte(0x0016+i) <= 0x2C) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) >= 0x30 and memory.readbyte(0x0016+i) <= 0x34) then choose3 = 0; end;
		if (memory.readbyte(0x0016+i) == 0x07) then choose3 = 0; end;
		
		if choose3 == 1 then
			memory.writebyte(0x0016+i,0x35);
			memory.writebyte(0x0058+i,0x00);
			memory.writebyte(0x00A0+i,0x00);
			memory.writebyte(0x001E+i,0x01);
			end;
		end;
	end;
	
	-- Block SCRAMBLERRRR (Chaos 30)
	if BrTimer > 0 then
		BrTimer = BrTimer-1;
		for i=0x500,0x69F do
			if (memory.readbyte(i) == (0xC0 or 0xC1)) then
				memory.writebyte(i,math.random(0x55,0x5E)) end;
			if (memory.readbyte(i) >= 0x55 and memory.readbyte(i) <= 0x5E) then
				memory.writebyte(i,math.random(0x55,0x5E)) end;
			if (memory.readbyte(i) >= 0x5F and memory.readbyte(i) <= 0x60) then
				memory.writebyte(i,math.random(0x5F,0x60)) end;
		end;
	end;
	
	-- Scroll Stop! (Chaos 31)
	if sfxtimer > 0 then
	sfxtimer = sfxtimer-1;
		if sfxtimer > 1 then
			memory.writebyte(0x0723,0x01);
		else
			memory.writebyte(0x0723,0x00);
		end;
	end;
	
	-- Bouncy Enemies (Chaos 33)
	if EBTimer > 0 then
		EBTimer = EBTimer-1;
		for i=0,4 do
			if (memory.readbyte(0x0016+i) == (0x00 or 0x01 or 0x02 or 0x03 or 0x04 or 0x05 or 0x06 or 0x12 or 0x0E)) then
				if memory.readbyte(0x001E+i) == 0x00 then
				memory.writebyte(0x001E+i,0x01);
				memory.writebyte(0x00CF+i,memory.readbyte(0x00CF+i)-0x02);
				memory.writebyte(0x00A0+i,math.random(0xFB,0xFD));
				end;
			end;
		end;
	end;
	
end;
--AAAA
--
--
end;

	-- Title Screen
	joyin = joypad.read(1);
	if titimer > 0 then titimer=titimer-1; end;
	
	
	if (memory.readbyte(0x0770) == 0x00) then
	chaostimer = math.random(300,600);
	safetimer = 0;
	memory.writebyte(0x07a2,0x1a);
	
	if memory.readbyte(0x000e) == 0x08 then
	title = 120;
	gui.text(156, 48,"CHAOS", "#F5BAA2", "#F55515");
	gui.text(152.5, 48,"\nEDITION", "#F5BAA2", "#F55515");
	gui.text(104, 121,"  By TheCyVap | 2022    ", "#FFFFFF", "#5C94FC");
	gui.text(194, 36,"v2.1", "#F5BAA2", "#F55515");
	gui.box(70, 169, 186, 183, "#F55515", "#202020");
	gui.box(72, 171, 184, 181, "#F55515", "#F5BAA2");
	gui.text(77, 173,"INFINITE LIVES:", "#F5BAA2", "#F55515");
	if inf == 0 then gui.text(162, 173,"OFF", "#F5BAA2", "#F55515"); end;
	if inf == 1 then gui.text(168, 173,"ON", "#F5BAA2", "#F55515"); end;
	gui.text(85, 185,"  Press [RIGHT]      \n    to toggle.", "#FFFFFF", "#5C94FC");
	
	if inf == 0 then -- Infinite Lives
	memory.writebyte(0x075A,0x04);
	end;
	
	memory.writebyte(0x07fc,memory.readbyte(0x077a));
	gui.box(0, 214, 256, 256, "#222222", "#222222");
	gui.text(25, 215,"Hold A to see the description/help.\nPress [UP] & [DOWN] to pick starting world.", "#FFFFFF", "#222222");
	
	
	gui.box(0, 128+hy, 256, 256, "#F55515", "#444444");
	gui.text(96,128+hy+3,"DESCRIPTION:", "#F5BAA2", "#F55515");
	gui.text(12,128+hy+13,"Like in SM64 Chaos Edition, many random\noccurances will happen.\nYou cannot control what, or when things happen.\nAll you can do is keep going, and hope you're\nlucky.\n \nThey don't call it CHAOS for no reason!\n \n(You can press [SELECT] in game to restart the \nlevel if you get stuck. At the cost of 1 life.)", "#F5BAA2", "#F55515");
	gui.text(149, 24,"  "..(memory.readbyte(0x075f)+1).."  ", "#FFFFFF", "#5C94FC");
	if titimer == 0 then
	if joyin['up'] then 
	if memory.readbyte(0x075f) < 0x07 then
	memory.writebyte(0x075f,memory.readbyte(0x075f)+0x01);
	end;
	titimer = 15;
	end;
	if joyin['down'] then 
	if memory.readbyte(0x075f) > 0x00 then
	memory.writebyte(0x075f,memory.readbyte(0x075f)+0xFF);
	end;
	titimer = 15;
	end;
	end;
	
	if joyin['right'] then 
		if rpress == 0 then
		inf = inf+1;
		if inf == 2 then inf = 0; end;
		end;
		rpress = 1;
	else
		rpress = 0;
	end;
	
	if joyin['A'] then 
	hy = hy - 8;
	if hy < -0 then
	hy = 0;
	end;
	end;
	if hy < 128 then
	hy = hy + 4;
	end;
	end;
end;

	if safetimer > 0 then
	local safe = math.ceil(safetimer/60);
	safetimer = safetimer-1;
	chaostimer = chaostimer+1;
	if sfxtimer > 1 then sfxtimer = 1; end;
	PTimer = 0;
	freezetimer = 0;
	spritetimer = 0;
	rushtimer = 0;
	matchtimer = 0;
	EBTimer = 0;
	GravTimer = 0;
	text(24,16, "CHAOS PAUSE: "..safe.."s");
	memory.writebyte(0x079F,0x09);
	if safetimer <= 10 then memory.writebyte(0x079F,0x04); end;
	end;

	-- Debug shit
	if debug == 1 then
	text(8,8, "Timer:"..chaostimer);
	text(8,16, "WZ:"..w1.." | "..w2.." | "..w3);
	text(8,24, "MT: "..musictimer);
	end;
end;
	
gui.register(gameloop);


while (true) do 

	FCEU.frameadvance();
end;